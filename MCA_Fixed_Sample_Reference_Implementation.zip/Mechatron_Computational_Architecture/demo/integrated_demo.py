"""Run the integrated MCA fixed-sample demonstration from any folder."""
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_integration.integration_unit import run_pipeline


def main() -> None:
    result = run_pipeline()
    print(f"Objective: {result['objective']}")
    print(f"Final simulated display: {result['final_display_text']}")
    print(f"Pipeline stages completed: {len(result['trace'])}")


if __name__ == "__main__":
    main()
