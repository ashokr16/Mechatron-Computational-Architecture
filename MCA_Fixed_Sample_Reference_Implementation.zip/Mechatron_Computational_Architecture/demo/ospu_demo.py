"""Demonstrate OSPU processing after CCU computation and OIU conversion."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_ccu.ccu_unit import CCU, build_fixed_iiu_sample
from mca_oiu import OIU
from mca_ospu import DisplayOSPU


def main() -> None:
    parser = argparse.ArgumentParser(description="Process an OIU display representation through OSPU")
    parser.add_argument("--input", help="binary MCR1 CR output from CCU; omit to create the fixed project sample")
    args = parser.parse_args()
    if args.input:
        ccu_cr = Path(args.input).read_bytes()
    else:
        iiu_cr = build_fixed_iiu_sample()
        ccu_cr = CCU().process(iiu_cr, objective="Respond to the greeting in the text input.")

    outputs = OIU().convert(ccu_cr)
    deliveries = [
        DisplayOSPU(destination=output.destination).receive(output)
        for output in outputs
    ]
    print(json.dumps({
        "oiu_representations_received": len(outputs),
        "ospu_deliveries": [
            {"destination": delivery.destination, "displayed_text": delivery.text}
            for delivery in deliveries
        ],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
