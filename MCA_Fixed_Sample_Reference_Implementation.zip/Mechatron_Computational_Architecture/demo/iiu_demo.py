"""Run fixed sensor samples through ISPUs and pass their results into IIU."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys
from uuid import NAMESPACE_URL, uuid5

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_ispu import AudioISPU, SensorSimulator, TextISPU, TouchISPU, VideoISPU
from mca_iiu import IIU
from mca_iiu.iiu_unit import HEADER


def main() -> None:
    source = SensorSimulator("demo-1")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    examples = [
        (TextISPU(), source.capture(
            "  Hello   MCA!  ", metadata={"source_sequence": 0}, captured_at=start)),
        (AudioISPU(), source.capture(
            [0.0, 0.25, -0.5, 0.1],
            metadata={"sample_rate_hz": 16000, "source_sequence": 1},
            captured_at=start + timedelta(seconds=1))),
        (VideoISPU(), source.capture(
            [{"data": b"frame-1", "width": 640, "height": 480},
             {"data": b"frame-2", "width": 640, "height": 480}],
            metadata={"frame_rate_fps": 30, "source_sequence": 2},
            captured_at=start + timedelta(seconds=2))),
        (TouchISPU(), source.capture(
            {"action": "down", "x": 12.0, "y": 30.0, "pressure": 0.7},
            metadata={"source_sequence": 3}, captured_at=start + timedelta(seconds=3))),
    ]

    # These are actual ISPU outputs. Stable IDs make the binary sample repeatable.
    results = []
    for index, (processor, reading) in enumerate(examples):
        result = processor.process(reading)
        result = replace(result, result_id=str(uuid5(NAMESPACE_URL, f"mca-ispu-demo:{index}")))
        results.append(result)
        print(f"ISPU {result.input_type}: {result.processed_data!r}")
        print(f"  quality={dict(result.quality)}")

    iiu = IIU()
    individual_crs = [iiu.convert(result) for result in results]
    integrated_cr = iiu.integrate(individual_crs)
    signature, total_length, input_count = HEADER.unpack_from(integrated_cr)
    print("IIU integrated CR:")
    print("  individual CR byte lengths:", [len(cr) for cr in individual_crs])
    print("  signature:", signature.decode("ascii"))
    print("  total bytes:", total_length)
    print("  input records:", input_count)
    print("  bytes (hex):", integrated_cr.hex())


if __name__ == "__main__":
    main()

