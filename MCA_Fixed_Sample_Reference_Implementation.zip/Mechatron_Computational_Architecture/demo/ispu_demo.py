"""Run deterministic examples for the ISPU unit from any working directory."""
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_ispu import AudioISPU, SensorSimulator, TextISPU, TouchISPU, VideoISPU

source = SensorSimulator("demo-1")
examples = [
    (TextISPU(), source.capture("  Hello   MCA!  ")),
    (AudioISPU(), source.capture([0.0, 0.25, -0.5, 0.1], metadata={"sample_rate_hz": 16000})),
    (VideoISPU(), source.capture([{"data": b"frame-1", "width": 640, "height": 480}, {"data": b"frame-2", "width": 640, "height": 480}], metadata={"frame_rate_fps": 30})),
    (TouchISPU(), source.capture({"action": "down", "x": 12.0, "y": 30.0, "pressure": 0.7})),
]
for processor, reading in examples:
    result = processor.process(reading)
    print(f"{result.input_type}: {result.processed_data!r}")
    print(f"  quality={dict(result.quality)}")
