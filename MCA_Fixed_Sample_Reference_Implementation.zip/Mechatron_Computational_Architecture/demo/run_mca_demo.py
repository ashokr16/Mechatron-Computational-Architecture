"""Run the fixed-sample MCA reference demonstration from any working directory."""
from pathlib import Path
import pprint
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_ROOT = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_ROOT) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_ROOT))

from mca_integration.integration_unit import run_pipeline


def heading(title: str) -> None:
    print(f"\n{'=' * 76}\n{title}\n{'=' * 76}")


def print_lead(lead: dict) -> None:
    print(f"  {lead['mechanism']} [{lead['kind']}]: {lead['value']}")
    if lead.get("supports"):
        print(f"    Contributing mechanisms: {', '.join(lead['supports'])}")


def main() -> None:
    print("MECHATRON COMPUTATIONAL ARCHITECTURE - FIXED-SAMPLE DEMONSTRATION")
    print("All paths are resolved relative to this program.")
    print("The bundled tests run before the demonstration.")
    subprocess.run(
        [sys.executable, str(PROJECT_ROOT / "run_tests.py")],
        cwd=PROJECT_ROOT,
        check=True,
    )

    result = run_pipeline()
    trace = result["trace"]
    stages = {entry["boundary"]: entry for entry in trace}

    heading("1. ISPU - process the fixed input samples")
    for sample in (item for item in trace if item["boundary"] == "sample_to_ispu"):
        print(f"{sample['input_type'].upper()} input: {sample['received_input']}")
        print(f"  Processed data: {sample['ispu_processed_data']}")
        print(f"  Quality: {sample['quality']}")
        print(f"  Metadata: {sample['metadata']}")

    heading("2. IIU - convert inputs to CR and integrate them")
    for item in stages["ispu_to_iiu"]["individual_crs"]:
        print(f"{item['input_type'].upper()}: {item['signature']} binary CR, {item['bytes']} bytes")
    integrated = stages["iiu_to_ccu"]
    print("IIU integrates the individual CRs into one Common Representation:")
    print(f"  Signature: {integrated['integrated_cr']['signature']}")
    print(f"  Records: {', '.join(integrated['input_types'])}")
    print(f"  Size: {integrated['integrated_cr']['total_bytes']} bytes")
    print(f"  SHA-256: {integrated['integrated_cr']['sha256']}")

    heading("3. CCU - systematic multi-mechanism reasoning")
    ccu = stages["ccu_to_oiu"]
    print("The CCU reads the integrated CR and determines its computational meaning.")
    print(f"  Objective: {ccu['objective']}")
    print(f"  Meaning: {ccu['meaning'].replace(chr(215), 'x')}")
    print("\nPARALLEL REASONING")
    print("All participating mechanisms start independent reasoning in parallel.")
    print("The fixed sample runs every listed mechanism; relevance is not preselected.")
    print(f"Mechanisms participating: {ccu['mechanisms_invoked']}")
    for name, counts in ccu["mechanism_runs"].items():
        print(f"  {name}: {counts['independent_leads']} independent lead(s)")

    print("\nDYNAMIC LEAD GENERATION")
    print("Independent leads generated from this sample:")
    independent_kinds = {
        "observation", "interpretation", "constraint", "validation", "measurement",
        "representation", "context", "interaction", "spatial", "temporal", "scope", "extension",
    }
    for lead in ccu["leads"]:
        if lead["kind"] in independent_kinds:
            print_lead(lead)

    print("\nDYNAMIC INTERACTION AND CROSS-CONTRIBUTION")
    print(f"The CCU runs {ccu['reasoning_rounds'] - 1} cross-contribution round(s).")
    print("Mechanisms receive leads from other mechanisms and use those contributions in further reasoning:")
    cross_kinds = {"cross_check", "cross_context", "candidate", "cross_contribution"}
    for lead in ccu["leads"]:
        if lead["kind"] in cross_kinds:
            print_lead(lead)
    extension = next((lead for lead in ccu["leads"] if lead["kind"] == "cross_contribution"), None)
    if extension:
        print("\nThe Additional reasoning mechanisms extension begins with no extra offline plugin")
        print("registered, then participates in cross-contribution by receiving other mechanisms' leads.")
        print(f"  It receives contributions from: {', '.join(extension['supports'])}")
        print("This shows a mechanism contributing even though its relevance was not established in advance.")

    print("\nSOLUTION EVALUATION")
    print(f"  Candidates: {ccu['solution_candidates']}")
    print(f"  Candidate contributors: {ccu['candidate_contributors']}")
    print(f"  Information sufficiency: {ccu['information_sufficiency']}")
    print(f"  Selected result stored in CR computational content: {ccu['selected_response_in_cr_content']}")
    print(f"  Input records preserved byte-for-byte: {ccu['input_records_byte_identical']}")
    print(f"  Updated CR: {ccu['updated_cr']['signature']}, {ccu['updated_cr']['total_bytes']} bytes")

    heading("4. OIU - convert the same CR content into an OSPU representation")
    oiu = stages["oiu_to_ospu"]
    print("OIU receives the CR from CCU. The CR remains the Common Representation until this conversion.")
    print(f"  CR passed to OIU unchanged: {oiu['cr_unchanged_by_oiu']}")
    for output in oiu["output_representations"]:
        print(f"  Destination: {output['destination']}")
        print(f"  Representation: {output['representation']}")
        print("  Metadata:")
        pprint.pp(output["metadata"], indent=4)
        print("  Payload:")
        pprint.pp(output["payload"], indent=4)
    print("This console preview shows OIU's converted output; OIU does not display it.")

    heading("5. OSPU - deliver the converted representation")
    print(result["final_display_text"])
    print("\nFixed sample demonstration; the samples and objective are predetermined.")


if __name__ == "__main__":
    main()
