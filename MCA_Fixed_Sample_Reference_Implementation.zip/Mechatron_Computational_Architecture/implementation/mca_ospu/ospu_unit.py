from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mca_oiu import OSPUOutput


class OSPUError(ValueError):
    pass


@dataclass(frozen=True)
class DisplayDelivery:
    destination: str
    text: str


class DisplayDevice:
    def display(self, text: str) -> DisplayDelivery:
        return DisplayDelivery("display_device", text)


class DisplayOSPU:
    """Validate and process the OIU display representation for a display device."""

    def __init__(self, device: Any | None = None, destination: str = "display_ospu"):
        self.device = device or DisplayDevice()
        self.destination = destination

    def receive(self, output: OSPUOutput) -> DisplayDelivery:
        if not isinstance(output, OSPUOutput):
            raise OSPUError("OSPU input must be an OIU output representation")
        if output.destination != self.destination:
            raise OSPUError("output is addressed to a different OSPU")
        if output.representation != "display.text.v1":
            raise OSPUError("unsupported display output representation")
        if not isinstance(output.metadata, dict):
            raise OSPUError("output metadata must be an object")
        if output.metadata.get("content_type") != "text/plain; charset=utf-8":
            raise OSPUError("unsupported display content type")
        if output.metadata.get("encoding") != "UTF-8":
            raise OSPUError("unsupported display text encoding")
        if not isinstance(output.payload, dict) or not isinstance(output.payload.get("text"), str):
            raise OSPUError("display payload must contain text")
        text = output.payload["text"]
        if not text or "\x00" in text:
            raise OSPUError("display text is empty or contains a null character")
        try:
            text.encode("utf-8", errors="strict")
        except UnicodeEncodeError as error:
            raise OSPUError("display text is not valid UTF-8") from error
        return self.device.display(text)

