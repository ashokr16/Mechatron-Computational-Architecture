"""End-to-end orchestration for the MCA reference units."""
from __future__ import annotations

import hashlib
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import NAMESPACE_URL, uuid5

from mca_ccu.ccu_unit import CCU, HEADER as CR_HEADER, decode_cr
from mca_iiu import IIU
from mca_ispu import AudioISPU, SensorSimulator, TextISPU, TouchISPU, VideoISPU
from mca_oiu import OIU
from mca_ospu import DisplayOSPU

OBJECTIVE = "Respond to the greeting in the text input."
EXPECTED_TEXT = "Hello! How can I help you?"


def _summary_cr(binary_cr: bytes, record_count: int) -> dict[str, Any]:
    signature, total_length, declared_count = CR_HEADER.unpack_from(binary_cr)
    return {
        "signature": signature.decode("ascii"),
        "total_bytes": total_length,
        "record_count": declared_count,
        "records_validated": record_count,
        "sha256": hashlib.sha256(binary_cr).hexdigest(),
    }


def run_pipeline() -> dict[str, Any]:
    """Run deterministic samples through the implemented MCA units."""
    source = SensorSimulator("demo-1")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    samples = [
        (TextISPU(), source.capture("  Hello   MCA!  ", metadata={"source_sequence": 0}, captured_at=start)),
        (AudioISPU(), source.capture([0.0, 0.25, -0.5, 0.1],
                                     metadata={"sample_rate_hz": 16000, "source_sequence": 1},
                                     captured_at=start + timedelta(seconds=1))),
        (VideoISPU(), source.capture([{"data": b"frame-1", "width": 640, "height": 480},
                                      {"data": b"frame-2", "width": 640, "height": 480}],
                                     metadata={"frame_rate_fps": 30, "source_sequence": 2},
                                     captured_at=start + timedelta(seconds=2))),
        (TouchISPU(), source.capture({"action": "down", "x": 12.0, "y": 30.0, "pressure": 0.7},
                                     metadata={"source_sequence": 3},
                                     captured_at=start + timedelta(seconds=3))),
    ]

    trace: list[dict[str, Any]] = []
    results = []
    for index, (processor, reading) in enumerate(samples):
        result = processor.process(reading)
        result = replace(result, result_id=str(uuid5(NAMESPACE_URL, f"mca-ispu-demo:{index}")))
        results.append(result)
        trace.append({
            "boundary": "sample_to_ispu",
            "input_type": result.input_type,
            "received_input": repr(reading.payload),
            "ispu_processed_data": repr(result.processed_data),
            "quality": dict(result.quality),
            "metadata": dict(result.metadata),
        })

    iiu = IIU()
    individual_crs = [iiu.convert(result) for result in results]
    trace.append({
        "boundary": "ispu_to_iiu",
        "individual_crs": [
            {"input_type": result.input_type, "bytes": len(cr), "signature": cr[:4].decode("ascii")}
            for result, cr in zip(results, individual_crs)
        ],
    })

    integrated_cr = iiu.integrate(individual_crs)
    integrated_parsed = decode_cr(integrated_cr)
    trace.append({
        "boundary": "iiu_to_ccu",
        "integrated_cr": _summary_cr(integrated_cr, len(integrated_parsed.records)),
        "input_types": [record.input_type for record in integrated_parsed.records],
    })

    updated_cr = CCU().process(integrated_cr, objective=OBJECTIVE)
    updated_parsed = decode_cr(updated_cr)
    records_preserved = [record.raw_record for record in integrated_parsed.records] == [
        record.raw_record for record in updated_parsed.records
    ]
    if not records_preserved:
        raise AssertionError("CCU changed input-record bytes")
    ccu_content = updated_parsed.computational_content.get("ccu_demo", {})
    response = ccu_content.get("selected_solution")
    trace.append({
        "boundary": "ccu_to_oiu",
        "objective": OBJECTIVE,
        "updated_cr": _summary_cr(updated_cr, len(updated_parsed.records)),
        "input_records_byte_identical": records_preserved,
        "meaning": ccu_content.get("meaning"),
        "mechanisms_invoked": len(ccu_content.get("mechanisms", [])),
        "mechanism_runs": ccu_content.get("mechanism_runs", {}),
        "leads": ccu_content.get("leads", []),
        "solution_candidates": ccu_content.get("solution_candidates", []),
        "candidate_contributors": ccu_content.get("candidate_contributors", {}),
        "information_sufficiency": ccu_content.get("information_sufficiency"),
        "reasoning_rounds": ccu_content.get("reasoning_rounds"),
        "selected_response_in_cr_content": response,
    })

    output_representations = OIU().convert(updated_cr)
    trace.append({
        "boundary": "oiu_to_ospu",
        "cr_received_as_binary": True,
        "cr_unchanged_by_oiu": updated_cr == updated_parsed.raw,
        "output_representations": [
            {"destination": output.destination, "representation": output.representation,
             "metadata": output.metadata, "payload": output.payload}
            for output in output_representations
        ],
    })

    display_ospu = DisplayOSPU()
    deliveries = [display_ospu.receive(output) for output in output_representations]
    if len(deliveries) != 1 or deliveries[0].text != EXPECTED_TEXT:
        raise AssertionError(f"unexpected display result: {[delivery.text for delivery in deliveries]!r}")
    trace.append({
        "boundary": "ospu_to_device",
        "ospu": "display_ospu",
        "device_interface": "simulated_display_device",
        "physical_hardware_controlled": False,
        "device_delivery": [{"destination": delivery.destination, "text": delivery.text}
                            for delivery in deliveries],
        "expected_text_verified": True,
    })
    return {"objective": OBJECTIVE, "trace": trace, "final_display_text": deliveries[0].text}
