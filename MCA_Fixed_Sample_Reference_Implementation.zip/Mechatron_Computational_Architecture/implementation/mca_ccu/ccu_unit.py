from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
import re
import struct
import sys
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from uuid import NAMESPACE_URL, UUID, uuid5


SIGNATURE = b"MCR1"
HEADER = struct.Struct("<4sQI")
RECORD_PREFIX = struct.Struct("<Q16sH16sQqII")
TLV_HEADER = struct.Struct("<HBBI")
U32 = struct.Struct("<I")
U64 = struct.Struct("<Q")
MAX_CR_BYTES = 64 * 1024 * 1024
MAX_METADATA_BYTES = 4 * 1024 * 1024
MAX_CONTENT_BYTES = 16 * 1024 * 1024
MAX_REASONING_ROUNDS = 6

INPUT_TYPES = {0: "generic", 1: "text", 2: "audio", 3: "video", 4: "touch"}
METADATA_FIELDS = {
    1: "valid", 2: "empty", 3: "character_count", 4: "word_count",
    5: "encoding", 6: "normalization", 7: "whitespace", 8: "sample_rate_hz",
    9: "frame_rate_fps", 10: "byte_count", 11: "format", 12: "channels",
    13: "sample_width_bytes", 14: "frame_count", 15: "duration_seconds",
    16: "sample_count", 17: "peak_amplitude", 18: "dimensions_consistent",
    19: "overlap_references", 20: "duplicate_references", 21: "context_references",
    22: "source_name", 23: "event_count", 100: "event_order", 101: "duplicate_of",
}
METADATA_CODES = {name: code for code, name in METADATA_FIELDS.items()}
TEXT, BOOLEAN, UINT64, FLOAT64, UUID_LIST = 1, 2, 3, 4, 5

MECHANISM_NAMES = (
    "Literal reasoning", "Literal meaning reasoning", "Grammar reasoning",
    "Typographical reasoning", "Linguistic reasoning", "Accent and dialect reasoning",
    "Translation and interpretation", "Rule-based reasoning", "Logical reasoning",
    "Analytical reasoning", "Rational reasoning", "Mathematical reasoning",
    "Symbolic reasoning", "Pattern reasoning", "Causal reasoning", "Analogical reasoning",
    "Contextual reasoning", "Interaction reasoning", "Temporal reasoning", "Spatial reasoning",
    "Objective-oriented reasoning", "Probabilistic reasoning", "Hypothetical reasoning",
    "Alternative-path reasoning", "Heuristic reasoning", "Domain-specific reasoning",
    "Engineering reasoning", "Scientific reasoning", "Medical reasoning", "Legal reasoning",
    "Financial reasoning", "Additional reasoning mechanisms",
)


class CRValidationError(ValueError):
    pass


@dataclass(frozen=True)
class InputRecord:
    input_id: bytes
    input_type: str
    source_token: bytes
    source_id: str
    source_sequence: int
    event_seconds: int
    event_nanoseconds: int
    ispu_metadata: dict[str, Any]
    iiu_metadata: dict[str, Any]
    payload_tag: int
    payload: Any
    raw_record: bytes

    @property
    def id_hex(self) -> str:
        return self.input_id.hex()


@dataclass(frozen=True)
class ParsedCR:
    raw: bytes
    records: tuple[InputRecord, ...]
    computational_content: dict[str, Any]
    content_offset: int


@dataclass(frozen=True)
class Lead:
    mechanism: str
    kind: str
    value: str
    evidence: tuple[str, ...] = ()
    supports: tuple[str, ...] = ()


@dataclass(frozen=True)
class ReasoningContext:
    records: tuple[InputRecord, ...]
    objective: str | None


def _require_range(offset: int, size: int, end: int, label: str) -> int:
    next_offset = offset + size
    if size < 0 or next_offset > end:
        raise CRValidationError(f"{label} exceeds its enclosing boundary")
    return next_offset


def _decode_metadata(data: bytes, label: str) -> dict[str, Any]:
    values: dict[str, Any] = {}
    offset = 0
    previous_code = -1
    while offset < len(data):
        if offset + TLV_HEADER.size > len(data):
            raise CRValidationError(f"truncated {label} TLV header")
        code, kind, present, length = TLV_HEADER.unpack_from(data, offset)
        offset += TLV_HEADER.size
        if code not in METADATA_FIELDS or code <= previous_code:
            raise CRValidationError(f"unknown, duplicate, or unordered {label} field code")
        if present not in (0, 1):
            raise CRValidationError(f"invalid presence marker in {label}")
        previous_code = code
        offset = _require_range(offset, length, len(data), f"{label} value")
        raw_value = data[offset - length:offset]
        if not present:
            if length:
                raise CRValidationError(f"absent {label} field must have zero value length")
            continue
        if kind == TEXT:
            try:
                value: Any = raw_value.decode("utf-8")
            except UnicodeDecodeError as error:
                raise CRValidationError(f"invalid UTF-8 in {label}") from error
        elif kind == BOOLEAN:
            if len(raw_value) != 1 or raw_value[0] not in (0, 1):
                raise CRValidationError(f"invalid boolean in {label}")
            value = bool(raw_value[0])
        elif kind == UINT64:
            if len(raw_value) != U64.size:
                raise CRValidationError(f"invalid unsigned integer width in {label}")
            value, = U64.unpack(raw_value)
        elif kind == FLOAT64:
            if len(raw_value) != 8:
                raise CRValidationError(f"invalid floating-point width in {label}")
            value, = struct.unpack("<d", raw_value)
            if not math.isfinite(value):
                raise CRValidationError(f"non-finite floating-point value in {label}")
        elif kind == UUID_LIST:
            if len(raw_value) % 16:
                raise CRValidationError(f"invalid UUID reference width in {label}")
            refs = tuple(UUID(bytes=raw_value[index:index + 16]) for index in range(0, len(raw_value), 16))
            if METADATA_FIELDS[code] == "duplicate_of":
                if len(refs) != 1:
                    raise CRValidationError("duplicate_of must contain one UUID")
                value = refs[0]
            else:
                value = refs
        else:
            raise CRValidationError(f"unknown value type in {label}")
        values[METADATA_FIELDS[code]] = value
    return values


def _restore_json_bytes(value: Any) -> Any:
    if isinstance(value, list):
        return [_restore_json_bytes(item) for item in value]
    if isinstance(value, dict):
        if set(value) == {"$bytes_hex"}:
            try:
                return bytes.fromhex(value["$bytes_hex"])
            except (TypeError, ValueError) as error:
                raise CRValidationError("invalid byte payload marker") from error
        return {key: _restore_json_bytes(item) for key, item in value.items()}
    return value


def _decode_payload(input_type: str, encoded: bytes) -> tuple[int, Any]:
    if len(encoded) < 9:
        raise CRValidationError("typed input payload is incomplete")
    tag = encoded[0]
    length, = U64.unpack_from(encoded, 1)
    if length != len(encoded) - 9:
        raise CRValidationError("typed input payload length does not match its record")
    body = encoded[9:]
    if tag == 1:
        payload: Any = body
    elif tag == 2:
        try:
            payload = body.decode("utf-8")
        except UnicodeDecodeError as error:
            raise CRValidationError("text payload is not valid UTF-8") from error
    elif tag == 3:
        if len(body) < U64.size:
            raise CRValidationError("numeric sample payload is incomplete")
        count, = U64.unpack_from(body)
        if count > (len(body) - U64.size) // 8 or U64.size + count * 8 != len(body):
            raise CRValidationError("numeric sample count does not match its payload length")
        payload = tuple(struct.unpack_from("<d", body, U64.size + index * 8)[0] for index in range(count))
        if any(not math.isfinite(sample) for sample in payload):
            raise CRValidationError("numeric sample payload contains a non-finite value")
    elif tag == 4:
        try:
            payload = _restore_json_bytes(json.loads(body.decode("utf-8")))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise CRValidationError("structured payload is not valid UTF-8 JSON") from error
    else:
        raise CRValidationError(f"unsupported provisional payload tag: {tag}")
    allowed_tags = {
        "generic": {1, 2, 3, 4}, "text": {1, 2}, "audio": {1, 3},
        "video": {4}, "touch": {4},
    }
    if tag not in allowed_tags[input_type]:
        raise CRValidationError("payload tag is inconsistent with the input type")
    return tag, payload


def _validate_metadata_values(record: InputRecord) -> None:
    boolean_fields = {"valid", "empty", "dimensions_consistent"}
    integer_fields = {
        "character_count", "word_count", "byte_count", "channels", "sample_width_bytes",
        "frame_count", "sample_count", "event_count", "event_order",
    }
    reference_fields = {"overlap_references", "duplicate_references", "context_references", "duplicate_of"}
    for label, metadata in (("ISPU", record.ispu_metadata), ("IIU", record.iiu_metadata)):
        for name, value in metadata.items():
            if name in boolean_fields and not isinstance(value, bool):
                raise CRValidationError(f"{label} field {name} must be boolean")
            if name in integer_fields and (isinstance(value, bool) or not isinstance(value, int)):
                raise CRValidationError(f"{label} field {name} must be an unsigned integer")
            if name in reference_fields and name != "duplicate_of" and not isinstance(value, tuple):
                raise CRValidationError(f"{label} field {name} must be a reference list")
            if name == "duplicate_of" and not isinstance(value, UUID):
                raise CRValidationError("IIU duplicate_of must be a UUID")
    if not isinstance(record.ispu_metadata.get("source_name"), str):
        raise CRValidationError("ISPU source_name is required")
    if not isinstance(record.iiu_metadata.get("event_order"), int):
        raise CRValidationError("IIU event_order is required")


def decode_cr(raw: bytes) -> ParsedCR:
    if not isinstance(raw, bytes) or len(raw) < HEADER.size + U64.size or len(raw) > MAX_CR_BYTES:
        raise CRValidationError("CR must be a bounded binary value with a complete header")
    signature, total_length, record_count = HEADER.unpack_from(raw)
    if signature != SIGNATURE or total_length != len(raw):
        raise CRValidationError("invalid MCR1 signature or declared total length")
    offset = HEADER.size
    records: list[InputRecord] = []
    for index in range(record_count):
        start = offset
        if offset + RECORD_PREFIX.size > len(raw):
            raise CRValidationError(f"input record {index} header is incomplete")
        length, input_id, type_code, source_token, sequence, seconds, nanos, flags = RECORD_PREFIX.unpack_from(raw, offset)
        if length < RECORD_PREFIX.size + 16 or start + length > len(raw):
            raise CRValidationError(f"input record {index} has an invalid record length")
        end = start + length
        if nanos >= 1_000_000_000 or flags != 0:
            raise CRValidationError(f"input record {index} has invalid timestamp or flags")
        if type_code not in INPUT_TYPES:
            raise CRValidationError(f"input record {index} has an unknown type code")
        offset += RECORD_PREFIX.size
        sections: list[bytes] = []
        for label in ("ISPU metadata", "IIU metadata"):
            if offset + U32.size > end:
                raise CRValidationError(f"input record {index} is missing {label} length")
            section_length, = U32.unpack_from(raw, offset)
            offset += U32.size
            if section_length > MAX_METADATA_BYTES or offset + section_length > end:
                raise CRValidationError(f"input record {index} has invalid {label} length")
            sections.append(raw[offset:offset + section_length])
            offset += section_length
        if offset + U64.size > end:
            raise CRValidationError(f"input record {index} is missing input-data length")
        payload_length, = U64.unpack_from(raw, offset)
        offset += U64.size
        if offset + payload_length != end:
            raise CRValidationError(f"input record {index} input-data length is inconsistent")
        ispu_metadata = _decode_metadata(sections[0], "ISPU metadata")
        iiu_metadata = _decode_metadata(sections[1], "IIU metadata")
        payload_tag, payload = _decode_payload(INPUT_TYPES[type_code], raw[offset:end])
        source_id = ispu_metadata.get("source_name")
        if not isinstance(source_id, str) or hashlib.sha256(source_id.encode("utf-8")).digest()[:16] != source_token:
            raise CRValidationError(f"input record {index} source identity does not match its token")
        record = InputRecord(input_id, INPUT_TYPES[type_code], source_token, source_id, sequence,
                             seconds, nanos, ispu_metadata, iiu_metadata, payload_tag,
                             payload, raw[start:end])
        _validate_metadata_values(record)
        records.append(record)
        offset = end
    content_offset = offset
    if offset + U64.size > len(raw):
        raise CRValidationError("computational-content length is missing")
    content_length, = U64.unpack_from(raw, offset)
    offset += U64.size
    if content_length > MAX_CONTENT_BYTES or offset + content_length != len(raw):
        raise CRValidationError("computational-content length or CR boundary is invalid")
    content_raw = raw[offset:offset + content_length]
    if content_length:
        try:
            computational_content = json.loads(content_raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise CRValidationError("demo computational content must be UTF-8 JSON") from error
        if not isinstance(computational_content, dict):
            raise CRValidationError("demo computational content must be a JSON object")
    else:
        computational_content = {}
    _validate_integrated_records(records)
    return ParsedCR(raw, tuple(records), computational_content, content_offset)


def _validate_integrated_records(records: list[InputRecord]) -> None:
    ids = {record.input_id for record in records}
    if len(ids) != len(records):
        raise CRValidationError("input IDs must be unique in the integrated CR")
    ordered = sorted(records, key=lambda record: (
        record.event_seconds, record.event_nanoseconds, record.source_sequence,
        record.source_token, record.input_id,
    ))
    for index, record in enumerate(ordered):
        if record.iiu_metadata["event_order"] != index:
            raise CRValidationError("IIU event_order does not match integrated record ordering")
        for name in ("overlap_references", "duplicate_references", "context_references"):
            for reference in record.ispu_metadata.get(name, ()):
                if reference.bytes == record.input_id or reference.bytes not in ids:
                    raise CRValidationError(f"ISPU {name} contains a self or dangling reference")
        duplicate = record.iiu_metadata.get("duplicate_of")
        if duplicate is not None and (duplicate.bytes == record.input_id or duplicate.bytes not in ids):
            raise CRValidationError("IIU duplicate_of contains a self or dangling reference")


def _text_records(context: ReasoningContext) -> list[InputRecord]:
    return [record for record in context.records if record.input_type == "text" and isinstance(record.payload, str)]


def _touch_events(context: ReasoningContext) -> list[tuple[InputRecord, dict[str, Any]]]:
    events = []
    for record in context.records:
        if record.input_type == "touch":
            items = record.payload if isinstance(record.payload, list) else [record.payload]
            events.extend((record, item) for item in items if isinstance(item, dict))
    return events


def _independent_reasoning(name: str, context: ReasoningContext) -> list[Lead]:
    records = context.records
    evidence_ids = tuple(record.id_hex for record in records)
    texts = _text_records(context)
    if name == "Literal reasoning" and texts:
        return [Lead(name, "observation", f'Text payload: "{texts[0].payload}"', (texts[0].id_hex,))]
    if name == "Literal meaning reasoning" and texts and re.search(r"\bhello\b", texts[0].payload, re.I):
        return [Lead(name, "interpretation", "The text is a greeting.", (texts[0].id_hex,))]
    if name == "Grammar reasoning" and texts:
        text = texts[0].payload
        return [Lead(name, "observation", "The text is a short punctuated phrase." if text.endswith("!")
                     else "The text is a short phrase.", (texts[0].id_hex,))]
    if name == "Typographical reasoning" and texts:
        return [Lead(name, "constraint", "No offline spelling lexicon is configured; no correction is asserted.",
                     (texts[0].id_hex,))]
    if name == "Linguistic reasoning" and texts:
        return [Lead(name, "observation", "The text uses a direct greeting form.", (texts[0].id_hex,))]
    if name in {"Accent and dialect reasoning", "Translation and interpretation"}:
        return [Lead(name, "scope", "No speech transcription or translation source is available.")]
    if name == "Rule-based reasoning":
        valid = all(record.ispu_metadata.get("valid") is True for record in records)
        return [Lead(name, "validation", f"All {len(records)} records carry valid ISPU status: {valid}.", evidence_ids)]
    if name == "Analytical reasoning":
        counts = {kind: sum(record.input_type == kind for record in records)
                  for kind in sorted({record.input_type for record in records})}
        return [Lead(name, "observation", f"Integrated input-type counts: {counts}.", evidence_ids)]
    if name == "Rational reasoning":
        return [Lead(name, "constraint", "Conclusions are limited to decoded payloads and validated metadata.", evidence_ids)]
    if name == "Mathematical reasoning":
        audio = [record for record in records if record.input_type == "audio" and isinstance(record.payload, tuple)]
        leads = []
        for record in audio:
            if record.payload:
                peak = max(abs(value) for value in record.payload)
                leads.append(Lead(name, "measurement", f"Audio sample count {len(record.payload)}; peak amplitude {peak:g}.",
                                  (record.id_hex,)))
        return leads
    if name == "Symbolic reasoning":
        mapping = ", ".join(f"{record.input_type}={record.id_hex[:8]}" for record in records)
        return [Lead(name, "representation", f"Input symbols map to record IDs: {mapping}.", evidence_ids)]
    if name == "Pattern reasoning":
        video = [record for record in records if record.input_type == "video"]
        leads = []
        for record in video:
            frames = record.payload if isinstance(record.payload, list) else []
            dimensions = [(frame.get("width"), frame.get("height")) for frame in frames if isinstance(frame, dict)]
            leads.append(Lead(name, "observation", f"Video payload contains {len(frames)} ordered frame entries; dimensions={dimensions}.",
                              (record.id_hex,)))
        return leads
    if name == "Causal reasoning":
        return [Lead(name, "constraint", "A single synchronized sample does not establish causal relationships.", evidence_ids)]
    if name == "Analogical reasoning":
        return [Lead(name, "scope", "No comparison case is present for analogy.", evidence_ids)]
    if name == "Contextual reasoning":
        return [Lead(name, "context", f"The integrated CR contains {len(records)} sensor-type records.", evidence_ids)]
    if name == "Interaction reasoning":
        events = _touch_events(context)
        return [Lead(name, "interaction", f"Touch action {event.get('action')} at ({event.get('x')}, {event.get('y')}).",
                     (record.id_hex,)) for record, event in events]
    if name == "Temporal reasoning":
        details = ", ".join(f"{record.input_type}:order={record.iiu_metadata['event_order']},seq={record.source_sequence}"
                             for record in sorted(records, key=lambda item: item.iiu_metadata["event_order"]))
        return [Lead(name, "temporal", f"Validated IIU event order is {details}.", evidence_ids)]
    if name == "Spatial reasoning":
        events = _touch_events(context)
        return [Lead(name, "spatial", f"Touch coordinates are x={event.get('x')}, y={event.get('y')}.",
                     (record.id_hex,)) for record, event in events]
    if name == "Objective-oriented reasoning":
        if context.objective:
            return [Lead(name, "objective", f"Demo objective: {context.objective}", evidence_ids)]
        return [Lead(name, "objective_gap", "No objective is stated in the CR or CCU invocation.", evidence_ids)]
    if name == "Probabilistic reasoning":
        return [Lead(name, "constraint", "The fixed sample provides no basis for a calibrated probability.", evidence_ids)]
    if name == "Hypothetical reasoning":
        return [Lead(name, "scope", "No hypothetical premise is supplied; none is introduced.", evidence_ids)]
    if name == "Alternative-path reasoning":
        return [Lead(name, "alternatives", f"Available evidence paths are {', '.join(sorted({r.input_type for r in records}))}.", evidence_ids)]
    if name == "Domain-specific reasoning":
        return [Lead(name, "scope", "No specialist domain objective or library is configured.", evidence_ids)]
    if name == "Engineering reasoning":
        return [Lead(name, "engineering", "MCR1 framing, input records, metadata, timestamps, and payload tags validated.", evidence_ids)]
    if name == "Scientific reasoning":
        audio = [record for record in records if record.input_type == "audio" and isinstance(record.payload, tuple)]
        return [Lead(name, "measurement", f"Numeric waveform samples are available for {len(audio)} audio record(s).",
                     tuple(record.id_hex for record in audio))]
    if name in {"Medical reasoning", "Legal reasoning", "Financial reasoning"}:
        return [Lead(name, "scope", "No applicable specialist task or validated specialist source is configured.", evidence_ids)]
    if name == "Additional reasoning mechanisms":
        return [Lead(name, "extension", "The extension point is active; no extra offline plugin is registered.", evidence_ids)]
    if name == "Logical reasoning":
        return [Lead(name, "constraint", "No contradiction is inferred from independent sensor observations.", evidence_ids)]
    if name == "Heuristic reasoning":
        return [Lead(name, "constraint", "Heuristic synthesis is deferred until cross-contributions are available.", evidence_ids)]
    return []


def _input_meaning(context: ReasoningContext) -> str:
    facts: list[str] = []
    texts = _text_records(context)
    if texts:
        facts.append(f'text greeting "{texts[0].payload}"')
    for record in context.records:
        if record.input_type == "audio" and isinstance(record.payload, tuple) and record.payload:
            peak = max(abs(value) for value in record.payload)
            facts.append(f"{len(record.payload)} numeric audio samples (peak amplitude {peak:g})")
        elif record.input_type == "video" and isinstance(record.payload, list):
            frames = record.payload
            sizes = {(frame.get("width"), frame.get("height")) for frame in frames if isinstance(frame, dict)}
            dimensions = next(iter(sizes)) if len(sizes) == 1 else None
            desc = f"{len(frames)} video frames"
            if dimensions:
                desc += f" ({dimensions[0]}×{dimensions[1]})"
            facts.append(desc)
    touches = _touch_events(context)
    for record, event in touches:
        facts.append(f"touch {event.get('action')} at ({event.get('x')}, {event.get('y')})")
    summary = "; ".join(facts) if facts else "No interpretable observations were found."
    video_note = " Video frame bytes are opaque; scene content is not inferred." if any(
        record.input_type == "video" for record in context.records) else ""
    audio_note = " Numeric audio is not transcribed as speech." if any(
        record.input_type == "audio" for record in context.records) else ""
    return f"Observed {summary}.{video_note}{audio_note}"


def _sample_solution(context: ReasoningContext, leads: tuple[Lead, ...]) -> str:
    if context.objective and "greeting" in context.objective.lower():
        texts = _text_records(context)
        if texts and re.search(r"\bhello\b", texts[0].payload, re.I):
            return "Hello! How can I help you?"
    return _input_meaning(context)


def _solution_evidence(context: ReasoningContext) -> tuple[str, ...]:
    if context.objective and "greeting" in context.objective.lower():
        texts = _text_records(context)
        if texts and re.search(r"\bhello\b", texts[0].payload, re.I):
            return (texts[0].id_hex,)
    return tuple(record.id_hex for record in context.records)


def _cross_contribute(name: str, context: ReasoningContext, leads: tuple[Lead, ...]) -> list[Lead]:
    evidence_ids = _solution_evidence(context)
    if name == "Logical reasoning":
        observations = [lead for lead in leads if lead.kind in {"observation", "measurement", "interaction", "spatial"}]
        if observations:
            return [Lead(name, "cross_check", f"Cross-checked {len(observations)} evidence leads; no incompatible claims detected.",
                         tuple(dict.fromkeys(item for lead in observations for item in lead.evidence)),
                         tuple(dict.fromkeys(lead.mechanism for lead in observations)))]
    if name == "Contextual reasoning" and leads:
        sources = tuple(dict.fromkeys(lead.mechanism for lead in leads
                                      if lead.kind in {"observation", "measurement", "interaction", "temporal", "spatial"}))
        if sources:
            return [Lead(name, "cross_context", f"Combined independent contributions from {', '.join(sources)}.",
                         evidence_ids, sources)]
    if name in {"Objective-oriented reasoning", "Heuristic reasoning"} and context.objective:
        supported = [lead for lead in leads if lead.kind not in {"scope", "constraint", "objective_gap"}]
        if len(supported) >= 3:
            solution = _sample_solution(context, leads)
            if any(lead.kind == "candidate" and lead.value == solution for lead in leads):
                return []
            return [Lead(name, "candidate", solution, evidence_ids,
                         tuple(dict.fromkeys(lead.mechanism for lead in supported)))]
    if name == "Additional reasoning mechanisms":
        if any(lead.mechanism == name and lead.kind == "cross_contribution" for lead in leads):
            return []
        cross = [lead for lead in leads if lead.kind in {"cross_context", "cross_check", "candidate"}]
        if cross:
            return [Lead(name, "cross_contribution", f"Received and carried {len(cross)} cross-mechanism contributions.",
                         evidence_ids, tuple(dict.fromkeys(lead.mechanism for lead in cross)))]
    return []


class ReasoningMechanism:
    def __init__(self, name: str):
        self.name = name

    def reason_independently(self, context: ReasoningContext) -> list[Lead]:
        return _independent_reasoning(self.name, context)

    def cross_contribute(self, context: ReasoningContext, leads: tuple[Lead, ...]) -> list[Lead]:
        return _cross_contribute(self.name, context, leads)


class CCU:
    def __init__(self, mechanisms: tuple[ReasoningMechanism, ...] | None = None):
        self.mechanisms = mechanisms or tuple(ReasoningMechanism(name) for name in MECHANISM_NAMES)

    def process(self, raw_cr: bytes, objective: str | None = None) -> bytes:
        parsed = decode_cr(raw_cr)
        context = ReasoningContext(parsed.records, objective)
        leads: list[Lead] = []
        mechanism_runs: dict[str, dict[str, int]] = {}
        with ThreadPoolExecutor(max_workers=len(self.mechanisms)) as executor:
            independent_results = list(executor.map(
                lambda mechanism: mechanism.reason_independently(context), self.mechanisms))
        for mechanism, independent in zip(self.mechanisms, independent_results):
            leads.extend(independent)
            mechanism_runs[mechanism.name] = {"independent_leads": len(independent), "cross_leads": 0}
        cross_rounds = 0
        for _ in range(MAX_REASONING_ROUNDS):
            previous = tuple(leads)
            new_leads: list[Lead] = []
            with ThreadPoolExecutor(max_workers=len(self.mechanisms)) as executor:
                contribution_results = list(executor.map(
                    lambda mechanism: mechanism.cross_contribute(context, previous), self.mechanisms))
            for mechanism, contributions in zip(self.mechanisms, contribution_results):
                for contribution in contributions:
                    if contribution not in previous and contribution not in new_leads:
                        new_leads.append(contribution)
                        mechanism_runs[mechanism.name]["cross_leads"] += 1
            if not new_leads:
                break
            leads.extend(new_leads)
            cross_rounds += 1
        candidates_by_value: dict[str, list[Lead]] = {}
        valid_ids = {record.id_hex for record in parsed.records}
        for candidate in leads:
            if candidate.kind == "candidate" and candidate.evidence and set(candidate.evidence).issubset(valid_ids):
                candidates_by_value.setdefault(candidate.value, []).append(candidate)
        candidates = list(candidates_by_value)
        selected_value = candidates[0] if candidates else None
        if selected_value:
            sufficiency = "sufficient_for_demo_objective"
            required_information: list[str] = []
            diagnosis = None
            solution = selected_value
        elif objective is None:
            sufficiency = "cannot_determine_without_objective"
            required_information = ["computational objective"]
            diagnosis = None
            solution = None
        else:
            sufficiency = "reasoning_failure_requires_diagnosis"
            required_information = []
            diagnosis = "The fixed offline mechanisms did not produce an evidence-supported solution."
            solution = None
        content = dict(parsed.computational_content)
        content["ccu_demo"] = {
            "meaning": _input_meaning(context),
            "objective": objective,
            "mechanisms": list(mechanism_runs),
            "mechanism_runs": mechanism_runs,
            "leads": [lead.__dict__ for lead in leads],
            "solution_candidates": candidates,
            "candidate_contributors": {
                value: list(dict.fromkeys(lead.mechanism for lead in contributions))
                for value, contributions in candidates_by_value.items()
            },
            "selected_solution": solution,
            "information_sufficiency": sufficiency,
            "required_information": required_information,
            "failure_diagnosis": diagnosis,
            "reasoning_rounds": 1 + cross_rounds,
        }
        return update_computational_content(parsed, content)


def update_computational_content(parsed: ParsedCR, content: dict[str, Any]) -> bytes:
    encoded_content = json.dumps(content, ensure_ascii=False, sort_keys=True,
                                 separators=(",", ":")).encode("utf-8")
    if len(encoded_content) > MAX_CONTENT_BYTES:
        raise CRValidationError("updated computational content exceeds the configured size limit")
    body = parsed.raw[HEADER.size:parsed.content_offset] + U64.pack(len(encoded_content)) + encoded_content
    total_length = HEADER.size + len(body)
    if total_length > MAX_CR_BYTES:
        raise CRValidationError("updated CR exceeds the configured size limit")
    return HEADER.pack(SIGNATURE, total_length, len(parsed.records)) + body


def build_fixed_iiu_sample(project_root: Path | None = None) -> bytes:
    implementation_root = Path(__file__).resolve().parents[1] if project_root is None else project_root.resolve()
    sys.path.insert(0, str(implementation_root))
    from mca_ispu import AudioISPU, SensorSimulator, TextISPU, TouchISPU, VideoISPU
    from mca_iiu import IIU

    source = SensorSimulator("demo-1")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    examples = [
        (TextISPU(), source.capture("  Hello   MCA!  ", metadata={"source_sequence": 0}, captured_at=start)),
        (AudioISPU(), source.capture([0.0, 0.25, -0.5, 0.1],
                                     metadata={"sample_rate_hz": 16000, "source_sequence": 1},
                                     captured_at=start + timedelta(seconds=1))),
        (VideoISPU(), source.capture([{"data": b"frame-1", "width": 640, "height": 480},
                                     {"data": b"frame-2", "width": 640, "height": 480}],
                                     metadata={"frame_rate_fps": 30, "source_sequence": 2},
                                     captured_at=start + timedelta(seconds=2))),
        (TouchISPU(), source.capture({"action": "down", "x": 12.0, "y": 30.0, "pressure": 0.7},
                                     metadata={"source_sequence": 3},
                                     captured_at=start + timedelta(seconds=3))),
    ]
    individual_crs = []
    for index, (processor, reading) in enumerate(examples):
        result = processor.process(reading)
        result = replace(result, result_id=str(uuid5(NAMESPACE_URL, f"mca-ispu-demo:{index}")))
        individual_crs.append(IIU().convert(result))
    return IIU().integrate(individual_crs)


def main() -> None:
    parser = argparse.ArgumentParser(description="Offline MCA CCU demo using the supplied ISPU/IIU prototype")
    parser.add_argument("--input", help="use an existing integrated MCR1 CR binary")
    parser.add_argument("--ispu-project", default=None,
                        help="optional implementation directory containing the ISPU and IIU packages")
    args = parser.parse_args()
    if args.input:
        raw_cr = Path(args.input).read_bytes()
    else:
        raw_cr = build_fixed_iiu_sample(Path(args.ispu_project) if args.ispu_project else None)
    objective = "Respond to the greeting in the text input."
    updated = CCU().process(raw_cr, objective=objective)
    content = decode_cr(updated).computational_content["ccu_demo"]
    summary = {
        "input_cr_bytes": len(raw_cr),
        "output_cr_bytes": len(updated),
        "binary_signature": SIGNATURE.decode("ascii"),
        "output_cr_hex": updated.hex(),
        "input_record_count": len(decode_cr(updated).records),
        "mechanisms_invoked": len(content["mechanisms"]),
        "cross_contribution_rounds": content["reasoning_rounds"] - 1,
        "response_stored_in_computational_content": bool(content["selected_solution"]),
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

