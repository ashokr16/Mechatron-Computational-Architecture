"""Provisional binary implementation of the MCA Input Integration Unit.

MCA requires the IIU to convert each processed input to CR and integrate the
individual CRs into one CR. Byte widths, codes, metadata TLVs, limits, ordering,
and duplicate/conflict handling in this module are prototype choices, not MCA
requirements. No human-facing decoder is provided here.
"""
from __future__ import annotations

import hashlib
import json
import math
import struct
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence
from uuid import UUID

from mca_ispu.ispu_base import ISPUResult


SIGNATURE = b"MCR1"
HEADER = struct.Struct("<4sQI")
RECORD_PREFIX = struct.Struct("<Q16sH16sQqII")
U32 = struct.Struct("<I")
U64 = struct.Struct("<Q")
TLV_HEADER = struct.Struct("<HBBI")  # code, value type, presence, value length

# Provisional bounded-size policy; measure and revise with representative data.
MAX_CR_BYTES = 64 * 1024 * 1024
MAX_METADATA_BYTES = 4 * 1024 * 1024

# Provisional codes for the prototype's current ISPU result fields.
INPUT_TYPES = {"generic": 0, "text": 1, "audio": 2, "video": 3, "touch": 4}
METADATA_CODES = {
    "valid": 1, "empty": 2, "character_count": 3, "word_count": 4,
    "encoding": 5, "normalization": 6, "whitespace": 7,
    "sample_rate_hz": 8, "frame_rate_fps": 9, "byte_count": 10,
    "format": 11, "channels": 12, "sample_width_bytes": 13,
    "frame_count": 14, "duration_seconds": 15, "sample_count": 16,
    "peak_amplitude": 17, "dimensions_consistent": 18,
    "overlap_references": 19, "duplicate_references": 20,
    "context_references": 21, "source_name": 22, "event_count": 23,
    "event_order": 100, "duplicate_of": 101,
}
_METADATA_NAMES = {code: name for name, code in METADATA_CODES.items()}
_TEXT, _BOOL, _U64, _F64, _UUID_LIST = 1, 2, 3, 4, 5


class IIUError(ValueError):
    """Invalid ISPU result or malformed provisional CR."""


@dataclass(frozen=True)
class _Record:
    input_id: bytes
    input_type: str
    source_id: str
    source_token: bytes
    source_sequence: int
    seconds: int
    nanoseconds: int
    ispu_metadata: dict[str, Any]
    iiu_metadata: dict[str, Any]
    payload: bytes  # typed, length-prefixed engineering payload


class IIU:
    """Convert ISPUResult objects to individual binary CRs and integrate them."""

    def convert(self, result: ISPUResult) -> bytes:
        """Return a one-record binary CR for one actual ISPU result."""
        record = self._from_result(result)
        return self._encode_cr([record])

    def integrate(self, individual_crs: Sequence[bytes]) -> bytes:
        """Integrate one-record binary CRs into a single binary CR."""
        if isinstance(individual_crs, (bytes, bytearray, str)) or not isinstance(individual_crs, Sequence):
            raise TypeError("integrate() expects a sequence of individual CR byte strings")
        records = []
        for cr in individual_crs:
            records.extend(self._read_individual_cr(cr))
        return self._integrate_records(records)

    def _from_result(self, result: ISPUResult) -> _Record:
        if not isinstance(result, ISPUResult):
            raise TypeError("convert() expects an ISPUResult")
        if result.input_type not in INPUT_TYPES:
            raise IIUError(f"unregistered input type: {result.input_type!r}")
        if not isinstance(result.sensor_id, str) or not result.sensor_id.strip():
            raise IIUError("sensor_id must be a non-empty string")
        try:
            input_id = UUID(result.result_id).bytes
        except (ValueError, AttributeError) as exc:
            raise IIUError("result_id must be a UUID") from exc
        timestamp = result.captured_at
        if not isinstance(timestamp, datetime) or timestamp.tzinfo is None or timestamp.utcoffset() is None:
            raise IIUError("captured_at must be timezone-aware")
        utc = timestamp.astimezone(timezone.utc)
        delta = utc - datetime(1970, 1, 1, tzinfo=timezone.utc)
        seconds = delta.days * 86400 + delta.seconds
        nanos = utc.microsecond * 1000  # datetime supplies microsecond precision
        if not -(2**63) <= seconds < 2**63:
            raise IIUError("timestamp is outside signed 64-bit epoch seconds")

        if not isinstance(result.metadata, Mapping) or not isinstance(result.quality, Mapping):
            raise IIUError("ISPU metadata and quality must be mappings")
        metadata = dict(result.metadata)
        sequence = metadata.pop("source_sequence", 0)
        if isinstance(sequence, bool) or not isinstance(sequence, int) or not 0 <= sequence < 2**64:
            raise IIUError("source_sequence must be an unsigned 64-bit integer")
        for key, value in result.quality.items():
            if key in metadata:
                raise IIUError(f"metadata field collision: {key}")
            metadata[key] = value
        if "source_name" in metadata:
            raise IIUError("source_name is reserved by the provisional IIU contract")
        metadata["source_name"] = result.sensor_id
        payload = _encode_payload(result.input_type, result.processed_data)
        return _Record(input_id, result.input_type, result.sensor_id,
                       hashlib.sha256(result.sensor_id.encode("utf-8")).digest()[:16],
                       sequence, seconds, nanos, metadata, {}, payload)

    def _integrate_records(self, records: list[_Record]) -> bytes:
        if not records:
            raise IIUError("at least one individual CR is required")
        ids = [record.input_id for record in records]
        if len(set(ids)) != len(ids):
            raise IIUError("input IDs must be unique within an integrated CR")
        by_token: dict[bytes, str] = {}
        for record in records:
            if by_token.setdefault(record.source_token, record.source_id) != record.source_id:
                raise IIUError("source ID token collision")
            _validate_references(record, set(ids))

        # PROVISIONAL: source + type + sequence identifies one source event.
        first_event: dict[tuple[str, str, int], _Record] = {}
        duplicate_of: dict[bytes, bytes] = {}
        for record in records:
            key = (record.source_id, record.input_type, record.source_sequence)
            previous = first_event.get(key)
            if previous is None:
                first_event[key] = record
            elif ((previous.seconds, previous.nanoseconds) == (record.seconds, record.nanoseconds)
                  and previous.payload == record.payload):
                duplicate_of[record.input_id] = previous.input_id
            else:
                raise IIUError("conflicting inputs reuse source_id, input_type, and source_sequence")

        # PROVISIONAL tie-break: timestamp, source sequence, source token, input ID.
        ordered = sorted(records, key=lambda r: (
            r.seconds, r.nanoseconds, r.source_sequence, r.source_token, r.input_id
        ))
        integrated = []
        for order, record in enumerate(ordered):
            iiu_meta = {"event_order": order}
            if record.input_id in duplicate_of:
                iiu_meta["duplicate_of"] = UUID(bytes=duplicate_of[record.input_id])
            integrated.append(_Record(
                record.input_id, record.input_type, record.source_id, record.source_token,
                record.source_sequence, record.seconds, record.nanoseconds,
                record.ispu_metadata, iiu_meta, record.payload,
            ))
        return self._encode_cr(integrated)

    def _encode_cr(self, records: Sequence[_Record]) -> bytes:
        body = b"".join(_encode_record(record) for record in records) + U64.pack(0)
        total_length = HEADER.size + len(body)
        if len(records) > 2**32 - 1 or total_length > MAX_CR_BYTES:
            raise IIUError("CR exceeds provisional count or size limit")
        return HEADER.pack(SIGNATURE, total_length, len(records)) + body

    def _read_individual_cr(self, data: bytes) -> list[_Record]:
        if not isinstance(data, bytes) or len(data) < HEADER.size + 8 or len(data) > MAX_CR_BYTES:
            raise IIUError("individual CR must be a bounded byte string")
        signature, total, count = HEADER.unpack_from(data)
        if signature != SIGNATURE or total != len(data):
            raise IIUError("invalid CR signature or total length")
        if count != 1:
            raise IIUError("expected a one-record individual CR")
        offset = HEADER.size
        record, offset = _decode_record(data, offset)
        if offset + 8 > len(data):
            raise IIUError("missing computational-content length")
        content_length, = U64.unpack_from(data, offset)
        offset += 8
        if content_length != 0 or offset != len(data):
            raise IIUError("individual CR must have empty computational content and no trailing bytes")
        return [record]


def _encode_record(record: _Record) -> bytes:
    ispu_metadata = _encode_metadata(record.ispu_metadata)
    iiu_metadata = _encode_metadata(record.iiu_metadata)
    if len(ispu_metadata) > MAX_METADATA_BYTES or len(iiu_metadata) > MAX_METADATA_BYTES:
        raise IIUError("metadata exceeds provisional size limit")
    length = (RECORD_PREFIX.size + 4 + len(ispu_metadata) + 4 + len(iiu_metadata)
              + 8 + len(record.payload))
    return (RECORD_PREFIX.pack(length, record.input_id, INPUT_TYPES[record.input_type],
                               record.source_token, record.source_sequence,
                               record.seconds, record.nanoseconds, 0)
            + U32.pack(len(ispu_metadata)) + ispu_metadata
            + U32.pack(len(iiu_metadata)) + iiu_metadata
            + U64.pack(len(record.payload)) + record.payload)


def _decode_record(data: bytes, offset: int) -> tuple[_Record, int]:
    if offset + RECORD_PREFIX.size > len(data):
        raise IIUError("truncated input record header")
    start = offset
    length, input_id, type_code, source_token, sequence, seconds, nanos, flags = RECORD_PREFIX.unpack_from(data, offset)
    end = start + length
    if length < RECORD_PREFIX.size + 16 or end > len(data) or nanos >= 1_000_000_000 or flags != 0:
        raise IIUError("invalid input record length, timestamp, or flags")
    input_names = {code: name for name, code in INPUT_TYPES.items()}
    if type_code not in input_names:
        raise IIUError("unknown input type code")
    offset += RECORD_PREFIX.size
    ispu_length, offset = _read_length32(data, offset, end, "ISPU metadata")
    if ispu_length > MAX_METADATA_BYTES:
        raise IIUError("ISPU metadata exceeds provisional size limit")
    ispu_metadata = _decode_metadata(data[offset:offset + ispu_length]); offset += ispu_length
    iiu_length, offset = _read_length32(data, offset, end, "IIU metadata")
    if iiu_length > MAX_METADATA_BYTES:
        raise IIUError("IIU metadata exceeds provisional size limit")
    iiu_metadata = _decode_metadata(data[offset:offset + iiu_length]); offset += iiu_length
    if offset + 8 > end:
        raise IIUError("missing input data length")
    payload_length, = U64.unpack_from(data, offset); offset += 8
    if offset + payload_length != end:
        raise IIUError("input data length exceeds record boundary")
    source_id = ispu_metadata.get("source_name")
    if not isinstance(source_id, str) or hashlib.sha256(source_id.encode("utf-8")).digest()[:16] != source_token:
        raise IIUError("source name does not match source ID token")
    return (_Record(input_id, input_names[type_code], source_id, source_token, sequence,
                    seconds, nanos, ispu_metadata, iiu_metadata,
                    data[offset:end]), end)


def _read_length32(data: bytes, offset: int, end: int, label: str) -> tuple[int, int]:
    if offset + 4 > end:
        raise IIUError(f"missing {label} length")
    length, = U32.unpack_from(data, offset)
    offset += 4
    if offset + length > end:
        raise IIUError(f"{label} exceeds record boundary")
    return length, offset


def _encode_metadata(metadata: Mapping[str, Any]) -> bytes:
    parts = []
    for name, value in metadata.items():
        if name not in METADATA_CODES:
            raise IIUError(f"unregistered provisional metadata field: {name!r}")
        code = METADATA_CODES[name]
        if name in {"overlap_references", "duplicate_references", "context_references", "duplicate_of"}:
            values = [value] if name == "duplicate_of" else value
            if not isinstance(values, (tuple, list)):
                raise IIUError(f"{name} must contain UUID references")
            try:
                raw = b"".join((v.bytes if isinstance(v, UUID) else UUID(str(v)).bytes) for v in values)
            except (ValueError, AttributeError) as exc:
                raise IIUError(f"{name} entries must be UUIDs") from exc
            kind = _UUID_LIST
        elif isinstance(value, bool):
            raw, kind = bytes((int(value),)), _BOOL
        elif isinstance(value, int):
            if value < 0 or value >= 2**64:
                raise IIUError(f"{name} is outside unsigned 64-bit range")
            raw, kind = U64.pack(value), _U64
        elif isinstance(value, float):
            if not math.isfinite(value):
                raise IIUError(f"{name} must be finite")
            raw, kind = struct.pack("<d", value), _F64
        elif isinstance(value, str):
            raw, kind = value.encode("utf-8"), _TEXT
        else:
            raise IIUError(f"unsupported value for metadata field {name!r}")
        parts.append((code, TLV_HEADER.pack(code, kind, 1, len(raw)) + raw))
    result = b"".join(part for _, part in sorted(parts))
    if len(result) > MAX_METADATA_BYTES:
        raise IIUError("metadata exceeds provisional size limit")
    return result


def _decode_metadata(data: bytes) -> dict[str, Any]:
    result = {}
    offset = 0
    while offset < len(data):
        if offset + TLV_HEADER.size > len(data):
            raise IIUError("truncated metadata TLV")
        code, kind, present, length = TLV_HEADER.unpack_from(data, offset)
        offset += TLV_HEADER.size
        if code not in _METADATA_NAMES or present not in (0, 1) or offset + length > len(data):
            raise IIUError("unknown or malformed metadata TLV")
        name = _METADATA_NAMES[code]
        if name in result:
            raise IIUError("duplicate metadata field")
        raw = data[offset:offset + length]; offset += length
        if not present:
            if length: raise IIUError("absent metadata value must be empty")
            continue
        if kind == _TEXT:
            try: value = raw.decode("utf-8")
            except UnicodeDecodeError as exc: raise IIUError("invalid UTF-8 metadata") from exc
        elif kind == _BOOL:
            if len(raw) != 1 or raw[0] not in (0, 1): raise IIUError("invalid boolean metadata")
            value = bool(raw[0])
        elif kind == _U64:
            if len(raw) != 8: raise IIUError("invalid integer metadata width")
            value, = U64.unpack(raw)
        elif kind == _F64:
            if len(raw) != 8: raise IIUError("invalid float metadata width")
            value, = struct.unpack("<d", raw)
            if not math.isfinite(value): raise IIUError("non-finite metadata float")
        elif kind == _UUID_LIST:
            if len(raw) % 16: raise IIUError("invalid UUID reference width")
            refs = tuple(UUID(bytes=raw[i:i + 16]) for i in range(0, len(raw), 16))
            if name == "duplicate_of":
                if len(refs) != 1: raise IIUError("duplicate_of requires one UUID")
                value = refs[0]
            else:
                value = refs
        else:
            raise IIUError("unknown metadata value type")
        result[name] = value
    return result


def _validate_references(record: _Record, ids: set[bytes]) -> None:
    for key in ("duplicate_references", "overlap_references", "context_references"):
        for reference in record.ispu_metadata.get(key, ()):
            target = reference.bytes if isinstance(reference, UUID) else UUID(str(reference)).bytes
            if target == record.input_id or target not in ids:
                raise IIUError(f"{key} contains a self or dangling reference")


def _encode_payload(input_type: str, payload: Any) -> bytes:
    # Payload type tags and encodings are provisional; data is otherwise opaque
    # to the IIU. Structured touch/video samples use canonical JSON with bytes hex.
    if isinstance(payload, bytes):
        tag, body = 1, payload
    elif isinstance(payload, str):
        tag, body = 2, payload.encode("utf-8")
    elif isinstance(payload, (list, tuple)) and all(
        isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
        for value in payload
    ):
        tag = 3
        body = U64.pack(len(payload)) + b"".join(struct.pack("<d", float(value)) for value in payload)
    else:
        try:
            body = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False,
                              ensure_ascii=False,
                              default=lambda value: {"$bytes_hex": value.hex()} if isinstance(value, bytes) else _unsupported(value)).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise IIUError(f"unsupported {input_type} payload for provisional encoding") from exc
        tag = 4
    encoded = bytes((tag,)) + U64.pack(len(body)) + body
    if len(encoded) > MAX_CR_BYTES:
        raise IIUError("input payload exceeds provisional CR size limit")
    return encoded


def _unsupported(value: Any) -> Any:
    raise TypeError(f"unsupported payload value type: {type(value).__name__}")

