"""Video frame-sequence validation; no decoding or vision inference."""
from typing import Any, Mapping
from .ispu_base import GenericISPU, finite_number

class VideoISPU(GenericISPU):
    input_type = "video"
    accepted_types = (list, tuple)

    def process_payload(self, payload: Any, metadata: Mapping[str, Any]):
        if not payload:
            raise ValueError("video frame sequence cannot be empty")
        frames = tuple(payload)
        dims = []
        for index, frame in enumerate(frames):
            if isinstance(frame, Mapping):
                width, height = frame.get("width"), frame.get("height")
                if (not isinstance(width, int) or isinstance(width, bool) or width <= 0 or
                    not isinstance(height, int) or isinstance(height, bool) or height <= 0):
                    raise ValueError(f"frame {index} must have positive integer width and height")
                if "data" not in frame or frame["data"] is None:
                    raise ValueError(f"frame {index} must contain non-None data")
                dims.append((width, height))
            elif frame is None:
                raise ValueError(f"frame {index} cannot be None")
            else:
                dims.append(None)
        rate = metadata.get("frame_rate_fps")
        if rate is not None and (not finite_number(rate) or rate <= 0):
            raise ValueError("frame_rate_fps must be a finite positive number")
        quality = {"valid": True, "frame_count": len(frames)}
        if rate is not None:
            quality["duration_seconds"] = len(frames) / rate
        known = [dim for dim in dims if dim is not None]
        if known:
            quality["dimensions_consistent"] = len(set(known)) == 1
        return frames, quality, dict(metadata), []

