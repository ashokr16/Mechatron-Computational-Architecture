"""Text payload decoding and deterministic normalization."""
import unicodedata
from typing import Any, Mapping
from .ispu_base import GenericISPU

class TextISPU(GenericISPU):
    input_type = "text"
    accepted_types = (str, bytes)

    def process_payload(self, payload: Any, metadata: Mapping[str, Any]):
        warnings = []
        if isinstance(payload, bytes):
            try:
                text = payload.decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                text = payload.decode("utf-8", errors="replace")
                warnings.append("Invalid UTF-8 bytes were replaced with the Unicode replacement character.")
        else:
            text = payload
        text = unicodedata.normalize("NFC", text)
        text = " ".join(text.split())
        quality = {"valid": True, "empty": not bool(text), "character_count": len(text),
                   "word_count": len(text.split())}
        return text, quality, {**dict(metadata), "encoding": "utf-8", "normalization": "NFC",
                               "whitespace": "collapsed"}, warnings

