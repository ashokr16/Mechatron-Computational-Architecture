"""Deterministic sensor-input simulator for local ISPU trials."""
from datetime import datetime, timezone
from typing import Any, Mapping
from .ispu_base import SensorInput

class SensorSimulator:
    def __init__(self, sensor_id: str = "simulated-sensor"):
        if not isinstance(sensor_id, str) or not sensor_id.strip():
            raise ValueError("sensor_id must be a non-empty string")
        self.sensor_id = sensor_id

    def capture(self, payload: Any, *, metadata: Mapping[str, Any] | None = None,
                captured_at: datetime | None = None) -> SensorInput:
        return SensorInput(payload=payload, sensor_id=self.sensor_id,
                           captured_at=captured_at or datetime.now(timezone.utc),
                           metadata={} if metadata is None else metadata)

