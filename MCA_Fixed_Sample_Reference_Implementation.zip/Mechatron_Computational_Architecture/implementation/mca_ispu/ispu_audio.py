"""Audio payload validation and basic measurements; no transcription or codec decoding."""
import io
import wave
from typing import Any, Mapping
from .ispu_base import GenericISPU, finite_number

class AudioISPU(GenericISPU):
    input_type = "audio"
    accepted_types = (bytes, bytearray, memoryview, list, tuple)

    def process_payload(self, payload: Any, metadata: Mapping[str, Any]):
        meta = dict(metadata)
        if isinstance(payload, (bytes, bytearray, memoryview)):
            raw = bytes(payload)
            if not raw:
                raise ValueError("audio payload cannot be empty")
            info = {"byte_count": len(raw), "format": "unknown"}
            if raw[:4] == b"RIFF" and raw[8:12] == b"WAVE":
                try:
                    with wave.open(io.BytesIO(raw), "rb") as wav:
                        rate, frames = wav.getframerate(), wav.getnframes()
                        if rate <= 0:
                            raise ValueError("WAV sample rate must be positive")
                        info.update(format="wav", sample_rate_hz=rate, channels=wav.getnchannels(),
                                    sample_width_bytes=wav.getsampwidth(), frame_count=frames,
                                    duration_seconds=frames / rate)
                except (wave.Error, EOFError) as exc:
                    raise ValueError(f"Invalid WAV audio payload: {exc}") from exc
            return raw, {"valid": True, **info}, meta, []
        samples = list(payload)
        if not samples:
            raise ValueError("audio sample sequence cannot be empty")
        if not all(finite_number(value) for value in samples):
            raise ValueError("audio samples must be finite numbers (not booleans)")
        rate = meta.get("sample_rate_hz")
        if rate is not None and (not finite_number(rate) or rate <= 0):
            raise ValueError("sample_rate_hz must be a finite positive number")
        quality = {"valid": True, "sample_count": len(samples),
                   "peak_amplitude": max(abs(x) for x in samples)}
        if rate is not None:
            quality["duration_seconds"] = len(samples) / rate
        return tuple(samples), quality, meta, []

