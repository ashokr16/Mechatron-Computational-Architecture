"""Shared ISPU envelope and validation; deliberately does not define the IIU contract."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from math import isfinite
from typing import Any, Mapping
from uuid import uuid4


def _validate_metadata(metadata: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(metadata, Mapping):
        raise TypeError("metadata must be a mapping")
    return dict(metadata)


@dataclass(frozen=True)
class SensorInput:
    """A reading from a real adapter or simulator."""
    payload: Any
    sensor_id: str = "simulated-sensor"
    captured_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.sensor_id, str) or not self.sensor_id.strip():
            raise ValueError("sensor_id must be a non-empty string")
        if not isinstance(self.captured_at, datetime) or self.captured_at.tzinfo is None or self.captured_at.utcoffset() is None:
            raise ValueError("captured_at must be a timezone-aware datetime")
        _validate_metadata(self.metadata)


@dataclass(frozen=True)
class ISPUResult:
    """Provisional local result. This is not yet the formal MCA-to-IIU contract."""
    input_type: str
    processed_data: Any
    sensor_id: str
    captured_at: datetime
    processed_at: datetime
    quality: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    warnings: tuple[str, ...] = ()
    result_id: str = field(default_factory=lambda: str(uuid4()))


class GenericISPU:
    """Base ISPU: common envelope checks plus transparent pass-through by default."""
    input_type = "generic"
    accepted_types: tuple[type, ...] | None = None

    def process(self, reading: SensorInput) -> ISPUResult:
        if not isinstance(reading, SensorInput):
            raise TypeError("process() expects a SensorInput instance")
        payload, quality, metadata, warnings = self.process_payload(reading.payload, reading.metadata)
        return ISPUResult(
            input_type=self.input_type, processed_data=payload, sensor_id=reading.sensor_id,
            captured_at=reading.captured_at, processed_at=datetime.now(timezone.utc),
            quality=quality, metadata=metadata, warnings=tuple(warnings),
        )

    def process_payload(self, payload: Any, metadata: Mapping[str, Any]):
        if payload is None:
            raise ValueError("sensor payload cannot be None")
        if self.accepted_types is not None and not isinstance(payload, self.accepted_types):
            expected = ", ".join(t.__name__ for t in self.accepted_types)
            raise TypeError(f"{self.input_type} payload must be one of: {expected}")
        return payload, {"valid": True}, _validate_metadata(metadata), []


def finite_number(value: Any) -> bool:
    """True for finite int/float values, excluding bool (a Python int subclass)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)
