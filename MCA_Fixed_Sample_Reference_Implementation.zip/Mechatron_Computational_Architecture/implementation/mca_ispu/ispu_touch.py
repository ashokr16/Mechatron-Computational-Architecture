"""Touch event validation and normalization."""
from typing import Any, Mapping
from .ispu_base import GenericISPU, finite_number

class TouchISPU(GenericISPU):
    input_type = "touch"
    accepted_types = (dict, list, tuple)

    def process_payload(self, payload: Any, metadata: Mapping[str, Any]):
        events = [payload] if isinstance(payload, dict) else list(payload)
        if not events:
            raise ValueError("touch event collection cannot be empty")
        normalized = []
        allowed = {"down", "move", "up", "cancel"}
        for index, event in enumerate(events):
            if not isinstance(event, Mapping):
                raise TypeError(f"touch event {index} must be a mapping")
            action = event.get("action")
            if action not in allowed:
                raise ValueError(f"touch event {index} action must be one of {sorted(allowed)}")
            item = dict(event)
            for axis in ("x", "y", "pressure"):
                if axis in item and (not finite_number(item[axis]) or item[axis] < 0):
                    raise ValueError(f"touch event {index} {axis} must be a finite non-negative number")
            normalized.append(item)
        return tuple(normalized), {"valid": True, "event_count": len(normalized)}, dict(metadata), []

