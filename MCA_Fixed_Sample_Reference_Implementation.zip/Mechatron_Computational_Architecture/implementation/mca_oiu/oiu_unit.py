from __future__ import annotations

import hashlib
import json
import math
import struct
from dataclasses import dataclass
from typing import Any
from uuid import UUID

SIGNATURE = b"MCR1"
HEADER = struct.Struct("<4sQI")
RECORD_PREFIX = struct.Struct("<Q16sH16sQqII")
TLV_HEADER = struct.Struct("<HBBI")
U32 = struct.Struct("<I")
U64 = struct.Struct("<Q")
MAX_CR_BYTES = 64 * 1024 * 1024
MAX_METADATA_BYTES = 4 * 1024 * 1024
MAX_CONTENT_BYTES = 16 * 1024 * 1024
INPUT_TYPES = {0: "generic", 1: "text", 2: "audio", 3: "video", 4: "touch"}
FIELDS = {
    1: "valid", 2: "empty", 3: "character_count", 4: "word_count", 5: "encoding",
    6: "normalization", 7: "whitespace", 8: "sample_rate_hz", 9: "frame_rate_fps",
    10: "byte_count", 11: "format", 12: "channels", 13: "sample_width_bytes",
    14: "frame_count", 15: "duration_seconds", 16: "sample_count", 17: "peak_amplitude",
    18: "dimensions_consistent", 19: "overlap_references", 20: "duplicate_references",
    21: "context_references", 22: "source_name", 23: "event_count", 100: "event_order",
    101: "duplicate_of",
}
TEXT, BOOLEAN, UINT64, FLOAT64, UUID_LIST = 1, 2, 3, 4, 5
FIELD_TYPES = {
    **{code: TEXT for code in (5, 6, 7, 11, 22)},
    **{code: BOOLEAN for code in (1, 2, 18)},
    **{code: UINT64 for code in (3, 4, 8, 10, 12, 13, 14, 16, 23, 100)},
    **{code: FLOAT64 for code in (9, 15, 17)},
    **{code: UUID_LIST for code in (19, 20, 21, 101)},
}
for _code in (8, 9, 15, 17):
    FIELD_TYPES[_code] = (UINT64, FLOAT64)


class OIUError(ValueError):
    pass


@dataclass(frozen=True)
class CRContent:
    original_cr: bytes
    record_count: int
    computational_content: dict[str, Any]


@dataclass(frozen=True)
class OSPUOutput:
    destination: str
    representation: str
    metadata: dict[str, Any]
    payload: dict[str, Any]


def _decode_metadata(data: bytes, label: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    offset = 0
    previous_code = -1
    while offset < len(data):
        if offset + TLV_HEADER.size > len(data):
            raise OIUError(f"truncated {label} TLV")
        code, kind, present, length = TLV_HEADER.unpack_from(data, offset)
        offset += TLV_HEADER.size
        if code not in FIELDS or code <= previous_code or present not in (0, 1):
            raise OIUError(f"unknown, duplicate, unordered, or invalid {label} field")
        previous_code = code
        allowed = FIELD_TYPES[code] if isinstance(FIELD_TYPES[code], tuple) else (FIELD_TYPES[code],)
        if kind not in allowed:
            raise OIUError(f"{label} field {FIELDS[code]} has the wrong value type")
        if length > len(data) - offset:
            raise OIUError(f"{label} value exceeds section boundary")
        value_bytes = data[offset:offset + length]
        offset += length
        if not present:
            if length:
                raise OIUError(f"absent {label} field has a value")
            continue
        if kind == TEXT:
            try:
                value: Any = value_bytes.decode("utf-8")
            except UnicodeDecodeError as error:
                raise OIUError(f"invalid UTF-8 in {label}") from error
        elif kind == BOOLEAN:
            if value_bytes not in (b"\x00", b"\x01"):
                raise OIUError(f"invalid boolean in {label}")
            value = bool(value_bytes[0])
        elif kind == UINT64:
            if len(value_bytes) != U64.size:
                raise OIUError(f"invalid integer width in {label}")
            value, = U64.unpack(value_bytes)
        elif kind == FLOAT64:
            if len(value_bytes) != 8:
                raise OIUError(f"invalid float width in {label}")
            value, = struct.unpack("<d", value_bytes)
            if not math.isfinite(value):
                raise OIUError(f"non-finite float in {label}")
        else:
            if len(value_bytes) % 16:
                raise OIUError(f"invalid reference width in {label}")
            references = tuple(UUID(bytes=value_bytes[i:i + 16]) for i in range(0, len(value_bytes), 16))
            if code == 101:
                if len(references) != 1:
                    raise OIUError("duplicate_of must contain one reference")
                value = references[0]
            else:
                value = references
        result[FIELDS[code]] = value
    return result


def _validate_payload(type_code: int, encoded: bytes) -> None:
    if len(encoded) < 9:
        raise OIUError("typed input payload is incomplete")
    tag = encoded[0]
    length, = U64.unpack_from(encoded, 1)
    body = encoded[9:]
    if length != len(body):
        raise OIUError("typed input payload length is inconsistent")
    allowed_tags = {0: {1, 2, 3, 4}, 1: {1, 2}, 2: {1, 3}, 3: {4}, 4: {4}}
    if tag not in allowed_tags[type_code]:
        raise OIUError("payload tag conflicts with input type")
    if tag == 2:
        try:
            body.decode("utf-8")
        except UnicodeDecodeError as error:
            raise OIUError("text payload is not valid UTF-8") from error
    elif tag == 3:
        if len(body) < U64.size:
            raise OIUError("numeric payload is incomplete")
        count, = U64.unpack_from(body)
        if count > (len(body) - U64.size) // 8 or U64.size + count * 8 != len(body):
            raise OIUError("numeric payload count is inconsistent")
        if any(not math.isfinite(struct.unpack_from("<d", body, U64.size + i * 8)[0]) for i in range(count)):
            raise OIUError("numeric payload contains non-finite values")
    elif tag == 4:
        try:
            json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise OIUError("structured payload is not valid JSON") from error


def read_ccu_cr(raw_cr: bytes) -> CRContent:
    if not isinstance(raw_cr, bytes) or len(raw_cr) < HEADER.size + U64.size or len(raw_cr) > MAX_CR_BYTES:
        raise OIUError("input must be a bounded binary MCR1 CR")
    signature, total_length, count = HEADER.unpack_from(raw_cr)
    if signature != SIGNATURE or total_length != len(raw_cr):
        raise OIUError("invalid MCR1 signature or total length")

    offset = HEADER.size
    records = []
    for index in range(count):
        start = offset
        if offset + RECORD_PREFIX.size > len(raw_cr):
            raise OIUError(f"record {index} header is incomplete")
        length, input_id, type_code, source_token, sequence, seconds, nanos, flags = RECORD_PREFIX.unpack_from(raw_cr, offset)
        if length < RECORD_PREFIX.size + 16 or length > len(raw_cr) - offset:
            raise OIUError(f"record {index} has invalid length")
        end = offset + length
        if type_code not in INPUT_TYPES or nanos >= 1_000_000_000 or flags != 0:
            raise OIUError(f"record {index} has invalid type, timestamp, or flags")
        offset += RECORD_PREFIX.size
        sections = []
        for label in ("ISPU metadata", "IIU metadata"):
            if offset + U32.size > end:
                raise OIUError(f"record {index} is missing {label} length")
            section_length, = U32.unpack_from(raw_cr, offset)
            offset += U32.size
            if section_length > MAX_METADATA_BYTES or section_length > end - offset:
                raise OIUError(f"record {index} has invalid {label} length")
            sections.append(raw_cr[offset:offset + section_length])
            offset += section_length
        if offset + U64.size > end:
            raise OIUError(f"record {index} is missing payload length")
        payload_length, = U64.unpack_from(raw_cr, offset)
        offset += U64.size
        if payload_length != end - offset:
            raise OIUError(f"record {index} payload length is inconsistent")
        ispu = _decode_metadata(sections[0], "ISPU metadata")
        iiu = _decode_metadata(sections[1], "IIU metadata")
        _validate_payload(type_code, raw_cr[offset:end])
        source_name = ispu.get("source_name")
        if not isinstance(source_name, str) or hashlib.sha256(source_name.encode()).digest()[:16] != source_token:
            raise OIUError(f"record {index} source identity is inconsistent")
        event_order = iiu.get("event_order")
        if not isinstance(event_order, int) or isinstance(event_order, bool):
            raise OIUError(f"record {index} has no valid IIU event order")
        records.append((input_id, seconds, nanos, sequence, source_token, ispu, iiu))
        offset = end

    ids = {record[0] for record in records}
    if len(ids) != len(records):
        raise OIUError("input IDs must be unique")
    ordered = sorted(records, key=lambda item: (item[1], item[2], item[3], item[4], item[0]))
    for event_order, record in enumerate(ordered):
        if record[6]["event_order"] != event_order:
            raise OIUError("IIU event order conflicts with integrated record ordering")
        for metadata in (record[5], record[6]):
            for key in ("overlap_references", "duplicate_references", "context_references"):
                for reference in metadata.get(key, ()):
                    if reference.bytes == record[0] or reference.bytes not in ids:
                        raise OIUError(f"{key} contains a self or dangling reference")
        duplicate = record[6].get("duplicate_of")
        if duplicate is not None and (duplicate.bytes == record[0] or duplicate.bytes not in ids):
            raise OIUError("duplicate_of contains a self or dangling reference")

    if offset + U64.size > len(raw_cr):
        raise OIUError("computational-content length is missing")
    content_length, = U64.unpack_from(raw_cr, offset)
    offset += U64.size
    if content_length > MAX_CONTENT_BYTES or content_length != len(raw_cr) - offset:
        raise OIUError("computational-content length or CR boundary is invalid")
    try:
        content = json.loads(raw_cr[offset:].decode("utf-8")) if content_length else {}
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise OIUError("demo computational content is invalid JSON") from error
    if not isinstance(content, dict):
        raise OIUError("computational content must be an object")
    return CRContent(raw_cr, count, content)


class OIU:
    def convert(self, raw_cr: bytes, destinations: tuple[str, ...] = ("display_ospu",)) -> tuple[OSPUOutput, ...]:
        cr = read_ccu_cr(raw_cr)
        ccu_content = cr.computational_content.get("ccu_demo")
        if not isinstance(ccu_content, dict):
            raise OIUError("CR has no CCU demo computational content")
        response = ccu_content.get("selected_solution")
        if not isinstance(response, str) or not response:
            raise OIUError("CCU content has no selected response")
        if not destinations or any(not isinstance(item, str) or not item for item in destinations):
            raise OIUError("at least one non-empty OSPU destination is required")
        if len(set(destinations)) != len(destinations):
            raise OIUError("duplicate OSPU destinations are not allowed")
        return tuple(OSPUOutput(
            destination=destination,
            representation="display.text.v1",
            metadata={
                "content_type": "text/plain; charset=utf-8",
                "encoding": "UTF-8",
                "output_id": f"ccu-demo-response-{index + 1}",
                "source": "CCU computational content",
                "input_record_count": cr.record_count,
                "objective": ccu_content.get("objective"),
                "priority": 0,
                "sequence": index,
            },
            payload={"text": response},
        ) for index, destination in enumerate(destinations))


