# OIU scope

## Architectural responsibility

The Output Integration Unit (OIU) consumes the same Common Representation (CR) whose computational content was updated by the CCU. It converts that content into one or more output-specific representations and associates required metadata, sequencing, coordination, synchronization, prioritization, and routing information. The corresponding Output Sensor Processing Unit (OSPU) performs sensor-specific processing and produces the physical or digital output.

The responsibilities in this section describe the MCA architecture. The implementation details below are prototype choices, not MCA requirements.

## Current prototype behavior

- Accepts a binary MCR1 CR and validates its header, records, metadata, payload encodings, references, event order, and computational-content section.
- Reads the CCU prototype's ccu_demo.selected_solution value from computational content.
- Produces an OSPUOutput representation for each requested destination. The current representation, display.text.v1, carries UTF-8 text payload and associated metadata for the corresponding OSPU.
- Includes destination and routing information in the representation. It does not call an OSPU, perform sensor-specific processing, or modify the input CR.
- The demo prints the representation as a console preview for inspection. This preview is not a device output.

## Prototype limits and open decisions

The MCR1 decoder rules, JSON computational-content schema, ccu_demo field names, output representation identifier, metadata schema, and default destination are implementation choices. They are not a finalized CR or OIU interface specification. The current converter expects a non-empty string in selected_solution; other output types and schemas remain to be defined.

