# CCU scope

## Architectural responsibility

The Central Computational Unit (CCU) determines the computational meaning of the CR, performs systematic reasoning toward the computational objective, evaluates supported solutions, and updates the computational content of the same CR. It assesses information sufficiency when no sufficiently supported solution emerges. The CCU does not convert the CR to another internal representation; output-specific conversion belongs to the Output Integration Unit (OIU).

The responsibilities in this section describe the MCA architecture. The implementation details below are prototype choices, not MCA requirements.

## Current prototype behavior

- Validates and decodes the provisional MCR1 binary CR produced by the current IIU implementation.
- Preserves the input records and CR representation, then adds JSON computational content to the same CR.
- Runs a fixed set of 32 named offline reasoning mechanisms. Independent passes run concurrently, followed by cross-contribution rounds up to a configured maximum of six.
- Uses deterministic, hand-coded checks for sample payloads. It calls no language models, external services, specialist systems, or physical sensors.
- Demonstrates a greeting-response objective using a fixed prototype response.
- Records leads, candidate solutions, the selected solution, reasoning rounds, and demo-specific information sufficiency in the ccu_demo content field.
- Reports a missing objective as an information gap. If an objective is present but no candidate emerges, it records a prototype reasoning failure for diagnosis.

## Prototype limits and open decisions

The reasoning mechanisms, lead vocabulary, candidate selection, fixed response, concurrency model, round limit, JSON content schema, and MCR1 decoder are prototype choices. They do not establish general reasoning quality, calibrated confidence, or real-world objective verification. Verification belongs to a later workflow stage.

