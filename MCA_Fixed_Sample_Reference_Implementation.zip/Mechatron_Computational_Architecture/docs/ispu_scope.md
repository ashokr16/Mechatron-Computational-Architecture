# ISPU scope

## Architectural responsibility

An Input Sensor Processing Unit (ISPU) performs sensor-specific processing for one input type and prepares its information for the Input Integration Unit (IIU). Each supported input type has its own ISPU; multiple physical sensors of the same type may use that unit. The ISPU does not construct the Common Representation (CR). CR conversion and integration belong to the IIU, while computational reasoning and information-sufficiency decisions belong to the Central Computational Unit (CCU).

The responsibilities in this section describe the MCA architecture. The implementation details below are prototype choices, not MCA requirements.

## Current prototype behavior

- Generic input passes through after envelope and payload checks.
- Text accepts strings or UTF-8 bytes, replaces invalid byte sequences with a warning, normalizes to NFC, and collapses whitespace.
- Audio accepts non-empty byte payloads or finite numeric samples. RIFF/WAVE headers are used to extract available WAV metadata.
- Video accepts a non-empty frame sequence and validates supplied frame dimensions and frame rate.
- Touch accepts the known action names and validates supplied x, y, and pressure values as finite and non-negative.
- Each processor returns a provisional ISPUResult envelope with processed data, provenance, quality information, metadata, and warnings.

## Prototype limits and open decisions

The result dataclasses and envelope are local reference-implementation conveniences, not a finalized MCA-to-IIU interface. Production sensor adapters, a finalized result and metadata schema, common error taxonomy, payload limits, and sensor-specific calibration and validation requirements remain open.

