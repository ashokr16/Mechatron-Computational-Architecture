# OSPU scope

## Architectural responsibility

An Output Sensor Processing Unit (OSPU) receives the output representation addressed to its associated output type. It performs output-specific processing and provides the processed result to the selected sensor, actuator, device, or software interface. Each output type has its own OSPU; multiple physical devices of the same type may use one unit.

The responsibilities in this section describe the MCA architecture. The implementation details below are prototype choices, not MCA requirements.

## Current prototype behavior

- The display OSPU accepts the OSPUOutput representation produced by the OIU.
- Validates its destination, representation identifier, UTF-8 content type and encoding, and text payload.
- Rejects empty text, null characters, invalid Unicode, and unsupported metadata values.
- Sends validated text to a display device adapter and returns a delivery record.
- The demo builds a sample CR, runs it through CCU and OIU, then passes the OIU representation to the display OSPU.

## Prototype limits and open decisions

The display representation identifier, metadata schema, validation rules, device adapter, error taxonomy, and supported output types are implementation choices. The current display adapter returns a delivery record for demonstration; production display hardware and other output-specific adapters remain to be defined.
