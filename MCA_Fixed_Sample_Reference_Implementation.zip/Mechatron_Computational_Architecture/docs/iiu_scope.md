# IIU scope

## Architectural responsibility

The Input Integration Unit (IIU) converts each processed ISPU input into the Common Representation (CR), then integrates those representations into one CR. Its architectural activities include synchronization, event ordering, duplicate and overlap detection, consolidation, relationship analysis, and context construction. Computational reasoning and solution selection belong to the Central Computational Unit (CCU).

The responsibilities in this section describe the MCA architecture. The implementation details below are prototype choices, not MCA requirements.

## Current prototype behavior

- IIU.convert() accepts an ISPUResult and encodes it as a one-record MCR1 binary CR.
- IIU.integrate() accepts one or more one-record CR byte strings and returns a single integrated CR.
- Records are ordered by UTC event timestamp, source sequence, source token, then input ID.
- Missing source_sequence defaults to zero.
- Repeated source/type/sequence events with matching timestamps and payloads are retained and annotated as duplicates. Conflicting reuse is rejected.
- Overlap, duplicate, and context references are validated and preserved. Payloads are not merged automatically.
- The current binary metadata registry accepts only registered fields. Provisional CR and metadata size limits are enforced.

## Prototype limits and open decisions

The binary CR format, metadata registry and types, payload encoding, error taxonomy, size limits, timestamp precision and clock policy, ordering tie-breaks, duplicate/conflict policy, and overlap handling remain subject to review. The current dataclasses and byte layout are implementation details, not a finalized MCA contract.

