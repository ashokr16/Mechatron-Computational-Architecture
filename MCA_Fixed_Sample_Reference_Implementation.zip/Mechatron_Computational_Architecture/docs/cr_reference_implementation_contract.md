# CR Reference Implementation Contract

## Status

| Item | Definition |
|---|---|
| MCA CR | Implementation-, technology-, hardware-, and software-independent architectural representation. MCA permits engineering representation and communication-medium choices. |
| This project | Fixed-sample reference implementation; binary was selected as its engineering representation. |
| Contract status | Provisional sample contract for this implementation only. `MCR1` is not a permanent MCA-wide format. |

## Unit-boundary contract

| Boundary | Representation and responsibility |
|---|---|
| ISPU -> IIU | ISPU supplies a processed `ISPUResult`; IIU converts it to CR. `ISPUResult` is this implementation's software interface, not the CR. |
| IIU -> CCU | IIU converts each result into a one-record binary CR, then integrates the records into one CR. |
| CCU -> OIU | CCU reasons within the CR and updates its computational content. The input records and CR representation remain unchanged. |
| OIU -> OSPU | OIU converts the CR's computational content into an OSPU-specific representation. That output representation is not the CR. OSPU processes it. |

## Fixed-sample input values

| Record | Processed payload | Selected metadata / quality values |
|---|---|---|
| Text | `Hello MCA!` | `encoding=utf-8`; `normalization=NFC`; `whitespace=collapsed`; `valid=true`; `character_count=10`; `word_count=2` |
| Audio | `(0.0, 0.25, -0.5, 0.1)` | `sample_rate_hz=16000`; `sample_count=4`; `peak_amplitude=0.5`; `duration_seconds=0.00025`; `valid=true` |
| Video | Two frames: `frame-1`, `frame-2`; each `640 x 480` | `frame_rate_fps=30`; `frame_count=2`; `dimensions_consistent=true`; `duration_seconds=0.06666666666666667`; `valid=true` |
| Touch | `action=down`, `x=12.0`, `y=30.0`, `pressure=0.7` | `event_count=1`; `valid=true` |

IIU event sequences are `0` through `3` for text, audio, video, and touch. Event times are `2026-01-01T00:00:00Z` through `2026-01-01T00:00:03Z` respectively.

## Fixed-sample CR values

| Stage | Value |
|---|---|
| Individual CR signature | `MCR1` |
| Individual record counts | `1` each |
| Integrated CR signature | `MCR1` |
| Integrated input types | `text`, `audio`, `video`, `touch` |
| Integrated record count | `4` |
| Integrated CR size | `998` bytes |
| CCU objective | `Respond to the greeting in the text input.` |
| CCU determined meaning | `Observed text greeting "Hello MCA!"; 4 numeric audio samples (peak amplitude 0.5); 2 video frames (640 x 480); touch down at (12.0, 30.0). Video frame bytes are opaque; scene content is not inferred. Numeric audio is not transcribed as speech.` |
| CCU mechanisms | `32` named mechanisms; independent and cross-contribution passes run concurrently |
| Cross-contribution rounds | `2` for this sample |
| Selected response in CR computational content | `Hello! How can I help you?` |
| CCU-updated CR size | `15209` bytes |
| Input record bytes after CCU | Preserved byte-for-byte |
| OIU representation | `display.text.v1` |
| OIU payload | `{"text": "Hello! How can I help you?"}` |
| OSPU destination | `display_ospu` |

Variable identifiers, timestamps, exact serialization of the JSON computational-content section, and binary field values are produced by the implementation. The values above describe the fixed sample; they do not define permanent MCA values.

## Provisional MCR1 layout

| Component | Current engineering representation |
|---|---|
| Header | Signature `MCR1`, total byte length, record count |
| Input record | Input ID, type code, source identity, sequence, UTC timestamp, ISPU metadata, IIU metadata, typed payload |
| Computational content | Length-prefixed section; empty before CCU, updated by CCU. Current implementation serializes this section as UTF-8 JSON bytes within the binary CR. |
| Metadata | Registered fields with provisional codes and types; event order and duplicate reference are IIU metadata. |
| Payloads | Type-tagged, length-prefixed data for generic, text, numeric audio, video, or touch records. |

The binary framing, field registry, type codes, byte order, metadata schema, payload tags, size limits, timestamp precision, ordering, duplicate policy, and computational-content schema are implementation choices. MCA does not require this binary layout or JSON computational content.

## CR continuity

```text
IIU creates and integrates CR
        -> CCU updates CR computational content only
        -> OIU receives that same CR and converts content for OSPU
```

The current implementation preserves the input-record bytes during CCU processing and passes the CCU-returned CR to OIU unchanged. OIU's conversion creates a separate `display.text.v1` output representation; it does not replace the CR earlier in the IIU -> CCU -> OIU path.

## Related documents

- `../mca_software_implementation_readme.md` - project and run instructions.
- `iiu_scope.md`, `ccu_scope.md`, `oiu_scope.md` - current unit behavior and prototype limits.
