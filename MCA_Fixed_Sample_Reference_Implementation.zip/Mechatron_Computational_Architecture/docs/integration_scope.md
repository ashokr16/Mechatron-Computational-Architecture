# Integration scope

## Architectural responsibility

The integrated workflow connects the ISPU, IIU, CCU, OIU, and OSPU in their defined order. It carries the same Common Representation from IIU through CCU to OIU, then passes OIU output representations to the corresponding OSPUs. Output verification determines whether the computational objective has been achieved.

The responsibilities in this section describe the MCA architecture. The implementation details below are prototype choices, not MCA requirements.

## Current prototype behavior

- Runs fixed text, audio, video, and touch samples through their ISPUs.
- Converts and integrates ISPU results into a binary CR with IIU.
- Processes the CR with CCU and confirms the input record bytes remain unchanged.
- Converts the CCU-updated binary CR into an OSPU-ready representation with OIU.
- Passes the representation to the display OSPU and records the simulated device delivery.
- Returns an in-memory trace of unit boundaries and results for the integration demo and end-to-end test.
- The full-run demo executes the bundled test suite before running the fixed pipeline and prints sample inputs, stage results, the OIU representation preview, and the simulated display result.

## Prototype limits and open decisions

The fixed inputs, greeting objective, deterministic identifiers, single display destination, in-memory trace, and simulated display are demo choices. The integration implementation does not control physical devices or implement general output verification and iterative computation. The full-run demo uses the project-bundled implementation and requires no external ISPU path or configuration file.
