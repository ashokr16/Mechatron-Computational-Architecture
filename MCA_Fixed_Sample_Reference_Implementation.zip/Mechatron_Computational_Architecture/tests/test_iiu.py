import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from mca_ispu import AudioISPU, SensorSimulator, TextISPU
from mca_iiu import IIU
from mca_iiu.iiu_unit import HEADER, SIGNATURE, _decode_record


class IIUTests(unittest.TestCase):
    def setUp(self):
        self.source = SensorSimulator("iiu-test-sensor")
        self.start = datetime(2026, 1, 1, tzinfo=timezone.utc)

    def test_converts_real_ispu_results_to_individual_binary_crs(self):
        text_result = TextISPU().process(self.source.capture(
            "  Hello MCA  ", metadata={"source_sequence": 1}, captured_at=self.start))
        audio_result = AudioISPU().process(self.source.capture(
            [0.0, 0.5], metadata={"source_sequence": 2, "sample_rate_hz": 8000},
            captured_at=self.start + timedelta(seconds=1)))
        iiu = IIU()
        crs = [iiu.convert(text_result), iiu.convert(audio_result)]
        self.assertEqual([HEADER.unpack_from(cr)[0] for cr in crs], [SIGNATURE, SIGNATURE])
        self.assertTrue(all(HEADER.unpack_from(cr)[2] == 1 for cr in crs))

    def test_integrates_individual_crs_and_orders_by_event_timestamp(self):
        later = TextISPU().process(self.source.capture(
            "later", metadata={"source_sequence": 1}, captured_at=self.start + timedelta(seconds=1)))
        earlier = TextISPU().process(self.source.capture(
            "earlier", metadata={"source_sequence": 2}, captured_at=self.start))
        iiu = IIU()
        integrated = iiu.integrate([iiu.convert(later), iiu.convert(earlier)])
        signature, total_length, count = HEADER.unpack_from(integrated)
        self.assertEqual((signature, total_length, count), (SIGNATURE, len(integrated), 2))
        offset = HEADER.size
        first, offset = _decode_record(integrated, offset)
        second, offset = _decode_record(integrated, offset)
        self.assertEqual(first.ispu_metadata["source_name"], "iiu-test-sensor")
        self.assertEqual(first.iiu_metadata["event_order"], 0)
        self.assertEqual(second.iiu_metadata["event_order"], 1)
        self.assertEqual(first.seconds, int(self.start.timestamp()))

    def test_duplicate_is_retained_and_conflicting_reuse_rejected(self):
        result = TextISPU().process(self.source.capture(
            "same", metadata={"source_sequence": 7}, captured_at=self.start))
        second_id = replace(result, result_id=str(uuid4()))
        iiu = IIU()
        merged = iiu.integrate([iiu.convert(result), iiu.convert(second_id)])
        self.assertEqual(HEADER.unpack_from(merged)[2], 2)

        conflict = replace(second_id, processed_data="different")
        with self.assertRaisesRegex(ValueError, "conflicting inputs"):
            iiu.integrate([iiu.convert(result), iiu.convert(conflict)])

    def test_malformed_total_length_is_rejected(self):
        result = TextISPU().process(self.source.capture("x", captured_at=self.start))
        broken = bytearray(IIU().convert(result))
        broken[4] ^= 1
        with self.assertRaisesRegex(ValueError, "signature or total length"):
            IIU().integrate([bytes(broken)])


if __name__ == "__main__":
    unittest.main()


