"""CCU tests use the project's fixed integrated ISPU/IIU sample."""
import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_ccu.ccu_unit import CCU, CRValidationError, build_fixed_iiu_sample, decode_cr


def sample_cr():
    return build_fixed_iiu_sample(IMPLEMENTATION_DIR)


class CCUTests(unittest.TestCase):
    def setUp(self):
        self.input_cr = sample_cr()

    def test_produces_fixed_greeting_response(self):
        output_cr = CCU().process(self.input_cr, "Respond to the greeting in the text input.")
        content = decode_cr(output_cr).computational_content["ccu_demo"]
        self.assertEqual(content["selected_solution"], "Hello! How can I help you?")
        self.assertEqual(content["information_sufficiency"], "sufficient_for_demo_objective")

    def test_preserves_input_records_and_cr_representation(self):
        before = decode_cr(self.input_cr)
        output_cr = CCU().process(self.input_cr, "Respond to the greeting in the text input.")
        after = decode_cr(output_cr)
        self.assertEqual(output_cr[:4], self.input_cr[:4])
        self.assertEqual(len(before.records), len(after.records))
        self.assertEqual([record.raw_record for record in before.records],
                         [record.raw_record for record in after.records])
        self.assertNotEqual(before.computational_content, after.computational_content)

    def test_invokes_all_mechanisms_and_cross_contributes(self):
        output_cr = CCU().process(self.input_cr, "Respond to the greeting in the text input.")
        content = decode_cr(output_cr).computational_content["ccu_demo"]
        self.assertEqual(len(content["mechanisms"]), 32)
        self.assertTrue(any(lead["kind"] == "cross_contribution" for lead in content["leads"]))
        self.assertGreaterEqual(content["reasoning_rounds"], 2)

    def test_missing_objective_is_reported_as_information_gap(self):
        output_cr = CCU().process(self.input_cr)
        content = decode_cr(output_cr).computational_content["ccu_demo"]
        self.assertIsNone(content["selected_solution"])
        self.assertEqual(content["information_sufficiency"], "cannot_determine_without_objective")
        self.assertIn("computational objective", content["required_information"])

    def test_rejects_malformed_cr(self):
        with self.assertRaises(CRValidationError):
            CCU().process(b"not an MCR1 CR", "Respond to the greeting")


if __name__ == "__main__":
    unittest.main()

