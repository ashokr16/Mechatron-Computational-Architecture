"""End-to-end tests for the bundled MCA reference units."""
from pathlib import Path
import sys
import unittest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_integration.integration_unit import EXPECTED_TEXT, run_pipeline


class IntegratedPipelineTests(unittest.TestCase):
    def test_fixed_sample_flows_through_all_units(self):
        result = run_pipeline()
        boundaries = [item["boundary"] for item in result["trace"]]
        self.assertEqual(result["final_display_text"], EXPECTED_TEXT)
        self.assertEqual(boundaries.count("sample_to_ispu"), 4)
        self.assertIn("ispu_to_iiu", boundaries)
        self.assertIn("iiu_to_ccu", boundaries)
        self.assertIn("ccu_to_oiu", boundaries)
        self.assertIn("oiu_to_ospu", boundaries)
        self.assertIn("ospu_to_device", boundaries)
        ccu_stage = next(item for item in result["trace"] if item["boundary"] == "ccu_to_oiu")
        self.assertTrue(ccu_stage["input_records_byte_identical"])
        self.assertIn("text greeting", ccu_stage["meaning"])
        self.assertEqual(ccu_stage["mechanisms_invoked"], 32)
        self.assertTrue(ccu_stage["leads"])
        self.assertTrue(ccu_stage["solution_candidates"])
        device_stage = next(item for item in result["trace"] if item["boundary"] == "ospu_to_device")
        self.assertFalse(device_stage["physical_hardware_controlled"])


if __name__ == "__main__":
    unittest.main()
