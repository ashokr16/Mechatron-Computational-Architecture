import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_oiu import OIU, OSPUOutput
from mca_ospu import DisplayOSPU, OSPUError
from test_oiu import sample_cr


def valid_output(**changes):
    values = {
        "destination": "display_ospu",
        "representation": "display.text.v1",
        "metadata": {"content_type": "text/plain; charset=utf-8", "encoding": "UTF-8"},
        "payload": {"text": "Hello! How can I help you?"},
    }
    values.update(changes)
    return OSPUOutput(**values)


class OSPUTests(unittest.TestCase):
    def test_processes_oiu_output_to_display(self):
        delivery = DisplayOSPU().receive(valid_output())
        self.assertEqual(delivery.text, "Hello! How can I help you?")
        self.assertEqual(delivery.destination, "display_device")

    def test_rejects_wrong_destination(self):
        with self.assertRaises(OSPUError):
            DisplayOSPU().receive(valid_output(destination="audio_ospu"))

    def test_rejects_wrong_representation(self):
        with self.assertRaises(OSPUError):
            DisplayOSPU().receive(valid_output(representation="audio.pcm.v1"))

    def test_rejects_invalid_payload(self):
        with self.assertRaises(OSPUError):
            DisplayOSPU().receive(valid_output(payload={"text": ""}))

    def test_rejects_missing_metadata(self):
        with self.assertRaises(OSPUError):
            DisplayOSPU().receive(valid_output(metadata=None))

    def test_rejects_wrong_content_type(self):
        with self.assertRaises(OSPUError):
            DisplayOSPU().receive(valid_output(metadata={"content_type": "application/json", "encoding": "UTF-8"}))

    def test_accepts_non_ascii_unicode(self):
        delivery = DisplayOSPU().receive(valid_output(payload={"text": "नमस्ते — café"}))
        self.assertEqual(delivery.text, "नमस्ते — café")

    def test_rejects_invalid_unicode_surrogate(self):
        with self.assertRaises(OSPUError):
            DisplayOSPU().receive(valid_output(payload={"text": "bad\ud800text"}))

    def test_end_to_end_oiu_to_display_ospu(self):
        output = OIU().convert(sample_cr())[0]
        delivery = DisplayOSPU().receive(output)
        self.assertEqual(delivery.text, "Hello! How can I help you?")


if __name__ == "__main__":
    unittest.main()

