import hashlib
import json
import struct
import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))

from mca_oiu import OIU, OIUError, read_ccu_cr
from mca_ccu.ccu_unit import CCU, build_fixed_iiu_sample


def sample_cr(include_dangling_reference=False):
    header = struct.Struct("<4sQI")
    prefix = struct.Struct("<Q16sH16sQqII")
    tlv = struct.Struct("<HBBI")
    source = "test-source"
    token = hashlib.sha256(source.encode()).digest()[:16]
    ispu = tlv.pack(9, 3, 1, 8) + struct.pack("<Q", 30)
    if include_dangling_reference:
        ispu += tlv.pack(19, 5, 1, 16) + b"x" * 16
    ispu += tlv.pack(22, 1, 1, len(source)) + source.encode()
    iiu = tlv.pack(100, 3, 1, 8) + struct.pack("<Q", 0)
    data = b"Hello MCA!"
    payload = b"\x02" + struct.pack("<Q", len(data)) + data
    record_length = prefix.size + 4 + len(ispu) + 4 + len(iiu) + 8 + len(payload)
    record = prefix.pack(record_length, b"i" * 16, 1, token, 0, 1, 0, 0)
    record += struct.pack("<I", len(ispu)) + ispu + struct.pack("<I", len(iiu)) + iiu
    record += struct.pack("<Q", len(payload)) + payload
    content = json.dumps({"ccu_demo": {"objective": "greeting", "selected_solution": "Hello! How can I help you?"}}).encode()
    total = header.size + len(record) + 8 + len(content)
    return header.pack(b"MCR1", total, 1) + record + struct.pack("<Q", len(content)) + content


class OIUTests(unittest.TestCase):
    def test_converts_binary_and_keeps_cr_unchanged(self):
        raw = sample_cr()
        digest = hashlib.sha256(raw).digest()
        output = OIU().convert(raw)[0]
        self.assertEqual(output.payload["text"], "Hello! How can I help you?")
        self.assertIn("content_type", output.metadata)
        self.assertEqual(read_ccu_cr(raw).original_cr, raw)
        self.assertEqual(hashlib.sha256(raw).digest(), digest)

    def test_converts_ccu_binary_to_oiu_representation(self):
        iiu_cr = build_fixed_iiu_sample()
        ccu_cr = CCU().process(iiu_cr, "Respond to the greeting in the text input.")
        original = bytes(ccu_cr)
        output = OIU().convert(ccu_cr)[0]
        self.assertEqual(output.representation, "display.text.v1")
        self.assertEqual(output.payload["text"], "Hello! How can I help you?")
        self.assertEqual(ccu_cr, original)
    def test_supports_multiple_named_destinations(self):
        outputs = OIU().convert(sample_cr(), ("screen_a", "screen_b"))
        self.assertEqual([item.destination for item in outputs], ["screen_a", "screen_b"])
        self.assertEqual([item.metadata["sequence"] for item in outputs], [0, 1])

    def test_rejects_malformed_record(self):
        raw = bytearray(sample_cr())
        raw[16:24] = struct.pack("<Q", 7)
        with self.assertRaises(OIUError):
            read_ccu_cr(bytes(raw))

    def test_rejects_empty_destination_list(self):
        with self.assertRaises(OIUError):
            OIU().convert(sample_cr(), ())

    def test_rejects_wrong_metadata_value_type(self):
        raw = bytearray(sample_cr())
        ispu_section_offset = 16 + struct.calcsize("<Q16sH16sQqII") + 4
        raw[ispu_section_offset + 2] = 1
        with self.assertRaises(OIUError):
            read_ccu_cr(bytes(raw))

    def test_rejects_dangling_reference(self):
        with self.assertRaises(OIUError):
            read_ccu_cr(sample_cr(include_dangling_reference=True))

    def test_rejects_corrupted_payload_length(self):
        raw = bytearray(sample_cr())
        offset = 16 + struct.calcsize("<Q16sH16sQqII")
        ispu_length, = struct.unpack_from("<I", raw, offset)
        offset += 4 + ispu_length
        iiu_length, = struct.unpack_from("<I", raw, offset)
        offset += 4 + iiu_length
        payload_length_offset = offset
        payload_length, = struct.unpack_from("<Q", raw, payload_length_offset)
        struct.pack_into("<Q", raw, payload_length_offset, payload_length - 1)
        with self.assertRaises(OIUError):
            read_ccu_cr(bytes(raw))

    def test_rejects_duplicate_destinations(self):
        with self.assertRaises(OIUError):
            OIU().convert(sample_cr(), ("screen_a", "screen_a"))

if __name__ == "__main__":
    unittest.main()



