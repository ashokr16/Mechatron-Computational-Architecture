import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMPLEMENTATION_DIR = PROJECT_ROOT / "implementation"
if str(IMPLEMENTATION_DIR) not in sys.path:
    sys.path.insert(0, str(IMPLEMENTATION_DIR))
from datetime import datetime
from mca_ispu import AudioISPU, GenericISPU, SensorInput, SensorSimulator, TextISPU, TouchISPU, VideoISPU

class ISPUTests(unittest.TestCase):
    def setUp(self): self.source = SensorSimulator("test-sensor")

    def test_generic_preserves_payload_and_provenance(self):
        payload = {"reading": 42}
        result = GenericISPU().process(self.source.capture(payload))
        self.assertIs(result.processed_data, payload)
        self.assertEqual((result.sensor_id, result.input_type), ("test-sensor", "generic"))

    def test_text_normalizes_unicode_and_whitespace(self):
        result = TextISPU().process(self.source.capture("  hello\n  world  "))
        self.assertEqual(result.processed_data, "hello world")
        self.assertEqual(result.quality["word_count"], 2)

    def test_text_invalid_utf8_warns(self):
        result = TextISPU().process(self.source.capture(b"a\xffb"))
        self.assertTrue(result.warnings)
        self.assertIn("\ufffd", result.processed_data)

    def test_audio_numeric_samples(self):
        result = AudioISPU().process(self.source.capture([0.0, -0.5, 0.25], metadata={"sample_rate_hz": 3}))
        self.assertEqual(result.quality["sample_count"], 3)
        self.assertEqual(result.quality["duration_seconds"], 1)

    def test_audio_rejects_nonfinite_samples_and_rates(self):
        for value in (float("nan"), float("inf"), True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                AudioISPU().process(self.source.capture([value]))
        for rate in (float("nan"), float("inf"), 0, True):
            with self.subTest(rate=rate), self.assertRaises(ValueError):
                AudioISPU().process(self.source.capture([0.2], metadata={"sample_rate_hz": rate}))

    def test_video_metadata_and_dimensions(self):
        result = VideoISPU().process(self.source.capture([{"data": b"x", "width": 10, "height": 10}], metadata={"frame_rate_fps": 2}))
        self.assertEqual(result.quality["duration_seconds"], 0.5)
        for rate in (float("nan"), float("inf"), True, 0):
            with self.subTest(rate=rate), self.assertRaises(ValueError):
                VideoISPU().process(self.source.capture([{"data": b"x", "width": 1, "height": 1}], metadata={"frame_rate_fps": rate}))

    def test_touch_rejects_nonfinite_and_boolean_coordinates(self):
        for value in (float("nan"), float("inf"), True, -1):
            with self.subTest(value=value), self.assertRaises(ValueError):
                TouchISPU().process(self.source.capture({"action": "down", "x": value}))

    def test_bad_envelopes_rejected(self):
        with self.assertRaises(TypeError): TextISPU().process("raw string")
        with self.assertRaises(ValueError): SensorInput("x", captured_at=datetime.now())
        with self.assertRaises(ValueError): SensorInput("x", sensor_id=" ")
        with self.assertRaises(TypeError): SensorInput("x", metadata=None)

    def test_empty_video_and_touch_rejected(self):
        with self.assertRaises(ValueError): VideoISPU().process(self.source.capture([]))
        with self.assertRaises(ValueError): TouchISPU().process(self.source.capture([]))


if __name__ == "__main__": unittest.main()

