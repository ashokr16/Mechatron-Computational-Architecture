# MCA Software Implementation Guide

*Software developed using OpenAI Codex and ChatGPT by Ashok Radhakrishnan.*

## 1. Purpose

This folder contains a Python reference implementation of the Mechatron Computational Architecture (MCA). It demonstrates the MCA unit responsibilities and computational path with a fixed sample workflow. The programs are implementation examples; implementation-specific formats, schemas, reasoning rules, limits, and adapters described here are prototypes, not architectural requirements.

The project uses the Python standard library. Each executable resolves its project and implementation paths relative to its own file, so it can be launched while the shell is in another folder. Use Python 3.

## 2. Architectural flow demonstrated

```text
Fixed inputs
    -> ISPU processing
    -> IIU: one CR per processed input, then one integrated CR
    -> CCU: reason within the same CR; update its computational content
    -> OIU: convert that content to an OSPU-specific output representation
    -> OSPU: process the representation and deliver simulated output
```

The Common Representation (CR) continues from IIU through CCU to OIU. CCU updates the computational content carried by the CR; it does not convert the CR into another internal representation. OIU consumes the CR containing that updated content and performs the output-specific conversion. OIU's console preview is for inspection; only OSPU processes the output representation for the simulated display.

## 3. Units and implementation behavior

### 3.1 Input Sensor Processing Units (ISPU)

**Architectural responsibility:** Process sensor-specific input and prepare the result for IIU. ISPUs do not construct or integrate CRs.

**Current implementation:** Separate text, audio, video, and touch processors. Processors validate supported sample forms and return an `ISPUResult` containing processed data, provenance, quality information, metadata, and warnings. Text is normalized to NFC with collapsed whitespace; audio accepts bytes or finite numeric samples; video validates a non-empty frame sequence and supplied dimensions; touch validates supported actions and supplied coordinates and pressure.

**Prototype boundary:** The Python result envelope, validation behavior, and metadata are implementation choices. Production sensor adapters, calibration, final interface schema, and common error handling are not defined here.

### 3.2 Input Integration Unit (IIU)

**Architectural responsibility:** Convert every processed input into a CR and integrate the resulting CRs into one CR. Integration responsibilities include synchronization, event ordering, duplicate and overlap handling, consolidation, relationships, and context construction. Computational reasoning belongs to CCU.

**Current implementation:** `IIU.convert()` encodes an `ISPUResult` into a one-record binary CR. `IIU.integrate()` accepts one-record CR byte strings and creates one integrated binary CR. The prototype encoding uses the `MCR1` signature, a registered metadata field set, typed payloads, and bounded sizes. Records are ordered by UTC timestamp, source sequence, source token, and input ID. Identical repeated events are retained and annotated; conflicting reuse is rejected.

**Prototype boundary:** Binary layout, metadata registry, payload encoding, timestamp precision, ordering rules, duplicate policy, size limits, and error behavior are provisional engineering choices.

### 3.3 Central Computational Unit (CCU)

**Architectural responsibility:** Read the CR, determine its computational meaning, reason toward the objective, evaluate candidate solutions, and update only the computational content of the same CR. Participating reasoning mechanisms operate in parallel and may dynamically generate leads, interact, and cross-contribute. Information sufficiency is assessed when no sufficiently supported solution has emerged.

**Current fixed-sample implementation:** CCU validates and decodes the prototype binary CR, preserves the input records, and writes its demo result into computational content. It runs 32 named, hand-coded offline reasoning mechanisms. Independent reasoning and cross-contribution passes use concurrent workers. Contributions can be used by other mechanisms over multiple rounds, including the Additional reasoning mechanisms extension after it receives other mechanisms' leads. The demo reports independent leads, cross-contributions, contributors, candidates, the selected result, and the sample's information-sufficiency status.

**Prototype boundary:** The mechanisms, rules, lead vocabulary, sample solution, candidate selection, concurrency model, round limit, computational-content schema, and CR decoder are fixed implementation choices. This project does not connect to language models, online libraries, external specialist systems, or plugins; it does not establish general reasoning quality or real-world verification.

### 3.4 Output Integration Unit (OIU)

**Architectural responsibility:** Consume the same CR containing CCU-updated computational content, convert that content into one or more output-specific representations, and associate required destination, routing, ordering, priority, coordination, and metadata information. OIU does not perform computational reasoning or device-specific processing.

**Current implementation:** Validates the `MCR1` CR and reads the prototype CCU result. It creates an `OSPUOutput` using the `display.text.v1` representation with UTF-8 text payload and metadata. It returns an output representation without modifying the input CR or invoking an OSPU. The full MCA demo prints this value as a console preview.

**Prototype boundary:** The decoder, computational-content fields, output representation identifier, metadata, and default destination are provisional. Other output types and representations are not implemented.

### 3.5 Output Sensor Processing Unit (OSPU)

**Architectural responsibility:** Process the output representation for an output type and provide the result to its associated sensor, actuator, device, or software interface.

**Current implementation:** The display OSPU validates destination, representation identifier, content type, encoding, and payload. It rejects invalid or empty display text, then passes validated text to a simulated display adapter and returns a delivery record.

**Prototype boundary:** The display adapter does not control physical hardware. Representation schema, validation, adapter behavior, errors, and other output-specific OSPUs remain implementation choices.

### 3.6 Integration

The orchestration connects the implemented units in order. It returns an in-memory trace showing sample processing, individual and integrated CR summaries, CCU results, OIU output representations, and the simulated OSPU delivery. The fixed samples are text, numeric audio, video frames, and a touch event. The fixed objective is to respond to the greeting in the text sample.

## 4. Run the full MCA demonstration

Run the full demo by its absolute path. Replace the example root with the directory where this project is stored:

```powershell
python C:\path\to\Mechatron_Computational_Architecture\demo\run_mca_demo.py
```

The program first runs all bundled unit and integration tests, then executes the fixed sample workflow. Its CCU presentation explicitly labels and shows:

- parallel independent reasoning across participating mechanisms
- dynamic leads generated from the sample
- interaction and cross-contributions between mechanisms
- contributions from a mechanism whose relevance was not established in advance
- candidate evaluation and the result stored in CR computational content

It then shows the CCU-updated CR reaching OIU, OIU's converted representation and metadata, and OSPU's simulated display result. No external ISPU project path or configuration file is needed.

## 5. Run the test suite independently

```powershell
python C:\path\to\Mechatron_Computational_Architecture\run_tests.py
```

The suite covers ISPU, IIU, CCU, OIU, OSPU, and end-to-end integration behavior. The full demonstration also runs this same suite before the sample workflow.

## 6. Run individual demos

```powershell
python C:\path\to\Mechatron_Computational_Architecture\demo\ispu_demo.py
python C:\path\to\Mechatron_Computational_Architecture\demo\iiu_demo.py
python C:\path\to\Mechatron_Computational_Architecture\demo\ccu_demo.py
python C:\path\to\Mechatron_Computational_Architecture\demo\oiu_demo.py
python C:\path\to\Mechatron_Computational_Architecture\demo\ospu_demo.py
python C:\path\to\Mechatron_Computational_Architecture\demo\integrated_demo.py
```

Each demo uses bundled sample data and the implementation included in this project.

## 7. Project contents

- `implementation/mca_ispu/` - base input envelope, simulator, and text, audio, video, and touch processors
- `implementation/mca_iiu/` - CR encoding, decoding, and integration
- `implementation/mca_ccu/` - binary CR validation, fixed reasoning mechanisms, lead generation, cross-contribution, and computational-content update
- `implementation/mca_oiu/` - CR validation and conversion to OSPU output representations
- `implementation/mca_ospu/` - output validation and simulated display delivery
- `implementation/mca_integration/` - full fixed-sample orchestration and trace
- `implementation/mca_units/` - combined public imports
- `demo/` - full workflow and per-unit demonstrations
- `tests/` - unit and integration tests
- `docs/` - unit scope documents and integration scope
- `run_tests.py` - project test-suite entry point
- `mca_software_implementation_readme.md` - this implementation guide

## 8. Scope and extension boundary

This is a fixed-sample reference implementation. Inputs and objective are predetermined; device delivery is simulated. It does not acquire live sensor data, use online reasoning libraries, load plugins, control physical hardware, or implement general output verification and iterative computation. Adding such capabilities requires concrete adapters, interfaces, data contracts, and validation beyond the current sample implementation.
