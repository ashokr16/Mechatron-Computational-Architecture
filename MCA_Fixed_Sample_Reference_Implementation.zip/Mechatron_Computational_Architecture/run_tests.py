"""Run the complete project unittest suite from any working directory."""
from pathlib import Path
import sys
import unittest

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "implementation"))
suite = unittest.defaultTestLoader.discover(str(PROJECT_ROOT / "tests"))
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())

